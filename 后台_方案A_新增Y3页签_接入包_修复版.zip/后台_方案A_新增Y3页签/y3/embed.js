/* =============================================================================
 * 方案 A · Y3 版果实编辑器「旁路挂载器」
 * -----------------------------------------------------------------------------
 * 目标：在现有 admin.html 里新增一个测试页签，原「果实管理」及全部原有功能
 *       一个字节都不改；测试通过后再走方案 B 替换。
 *
 * 为什么能零侵入：
 *  1) 新按钮【故意不带 data-tab】→ admin.js:5599 的 nav 委托 closest('[data-tab]')
 *     找不到它，不会调用 switchTab（switchTab 遇到未知 tab 会因 TAB_INFO/R 未定义报错）。
 *  2) 不覆盖任何 window.* 全局，不修改 admin.js / admin.css / 任何存档 key。
 *  3) 用 capture 阶段监听：点回任意原页签时先把视图还原，再放行给原委托处理。
 *  4) Y3 编辑器跑在同源 iframe 里，独立 document / 独立 localStorage key，
 *     键盘事件天然不冒泡到父页；测试期禁用顶部保存/发布按钮，防误写正式配置。
 *
 * admin.html 只需要加这一行（放在 admin.js 之后）：
 *   <script src="y3/embed.js"></script>
 * ========================================================================== */
(function () {
  'use strict';
  if (window.Y3Embed) return;                       // 防重复加载

  var STAGING_KEY = 'wowpinball.y3.staging.v1';     // 暂存区，与正式 key 完全不同
  var FORMAL_KEYS = ['wowpinball.config.v1', 'wowpinball.snapshots.v1', 'wowpinball.preview.v1'];

  /* 从自身 script src 推出 y3/ 的绝对地址，避免硬编码域名 */
  function baseOf() {
    var s = document.currentScript;
    if (!s) {
      var all = document.getElementsByTagName('script');
      for (var i = all.length - 1; i >= 0; i--) {
        if (/y3\/embed\.js/.test(all[i].src || '')) { s = all[i]; break; }
      }
    }
    var src = (s && s.src) || 'y3/embed.js';
    return src.replace(/embed\.js.*$/, '');
  }
  var BASE = baseOf();
  var $ = function (s) { return document.querySelector(s); };

  var St = {
    on: false, btn: null, panel: null, frame: null,
    prevActive: null, origTitle: '', origSub: '',
    guard: [], flashTimer: null
  };

  /* ---------------- 样式（动态注入，admin.css 一行都不改） ---------------- */
  function injectCss() {
    if ($('#y3EmbedCss')) return;
    var l = document.createElement('link');
    l.id = 'y3EmbedCss'; l.rel = 'stylesheet'; l.href = BASE + 'embed.css';
    document.head.appendChild(l);
  }

  /* ---------------- 侧栏新按钮 ---------------- */
  function buildNav() {
    var nav = $('#nav');
    if (!nav) return null;
    if ($('#y3NavBtn')) return $('#y3NavBtn');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.id = 'y3NavBtn';
    btn.className = 'nav-item y3-nav-item';
    // 关键：这里绝不能出现 data-tab
    btn.setAttribute('title', 'Y3 版果实逻辑编辑器（测试）· 独立数据，不影响原「果实管理」');
    btn.innerHTML = '<i class="ni ni-skill"></i><span>果实编辑器 · Y3版</span>' +
                    '<em class="y3-test">TEST</em>';
    var anchor = nav.querySelector('[data-tab="skills"]');
    if (anchor && anchor.parentNode === nav) nav.insertBefore(btn, anchor.nextSibling);
    else nav.appendChild(btn);
    return btn;
  }

  /* ---------------- 主区面板（与 #content 并列，不覆盖它） ---------------- */
  function buildPanel() {
    if ($('#y3Panel')) return $('#y3Panel');
    var main = $('.main') || $('main');
    var content = $('#content');
    if (!main) return null;
    var sec = document.createElement('section');
    sec.id = 'y3Panel';
    sec.hidden = true;
    sec.innerHTML =
      '<div class="y3-bar">' +
        '<span class="y3-pill">Y3 版 · 测试中</span>' +
        '<span class="y3-note">独立数据集 · 原「果实管理」完全保留 · 此页编辑不会写入 data/game-config.json</span>' +
        '<span class="y3-spacer"></span>' +
        '<span id="y3StagingInfo" class="y3-staging">未暂存</span>' +
        '<button type="button" id="y3BtnStage" class="y3-btn">暂存到主后台</button>' +
        '<button type="button" id="y3BtnDownload" class="y3-btn">下载暂存</button>' +
        '<button type="button" id="y3BtnClear" class="y3-btn y3-btn-danger">清空暂存</button>' +
        '<button type="button" id="y3BtnBack" class="y3-btn y3-btn-primary">← 返回原后台</button>' +
      '</div>' +
      '<div class="y3-flash" id="y3Flash" hidden></div>' +
      '<iframe id="y3Frame" class="y3-frame" title="Y3 版果实逻辑编辑器"></iframe>';
    if (content && content.parentNode === main) main.insertBefore(sec, content.nextSibling);
    else main.appendChild(sec);
    return sec;
  }

  /* ---------------- 顶部按钮防护 ---------------- */
  function guardButtons(on) {
    ['saveBtn', 'previewBtn', 'publishBtn'].forEach(function (id) {
      var b = document.getElementById(id);
      if (!b) return;
      if (on) {
        St.guard.push({ el: b, was: b.disabled, title: b.getAttribute('title') });
        b.disabled = true;
        b.setAttribute('title', 'Y3 测试模式下已禁用：请先「返回原后台」再保存 / 发布，避免误写正式配置');
      }
    });
    if (!on) {
      St.guard.forEach(function (g) {
        g.el.disabled = g.was;
        if (g.title === null) g.el.removeAttribute('title'); else g.el.setAttribute('title', g.title);
      });
      St.guard = [];
    }
  }

  function setTitle(t, s) {
    var a = $('#pageTitle'), b = $('#pageSub');
    if (a) a.textContent = t;
    if (b) b.textContent = s;
  }
  function restoreTitleLater() {
    setTimeout(function () {
      if (!St.on) setTitle(St.origTitle, St.origSub);
    }, 140);   // 覆盖 admin.js 异步装载完成后的 refresh()
  }

  function flash(msg, bad) {
    var f = $('#y3Flash'); if (!f) return;
    f.textContent = msg;
    f.className = 'y3-flash' + (bad ? ' bad' : '');
    f.hidden = false;
    clearTimeout(St.flashTimer);
    St.flashTimer = setTimeout(function () { f.hidden = true; }, 2600);
  }

  function updateStagingInfo() {
    var el = $('#y3StagingInfo'); if (!el) return;
    var n = 0;
    try {
      var raw = localStorage.getItem(STAGING_KEY);
      if (raw) {
        var d = JSON.parse(raw);
        n = (d && d.fruits && d.fruits.length) || 0;
      }
    } catch (e) { /* 忽略 */ }
    el.textContent = n ? ('已暂存 ' + n + ' 个果实（未写入正式配置）') : '未暂存';
    el.className = 'y3-staging' + (n ? ' has' : '');
  }

  /* ---------------- 进入 / 退出 ---------------- */
  function enter() {
    if (St.on || !St.panel) return;
    // 原后台的抽屉 / 确认框 / 快捷键面板是 fixed 全局弹层，会浮在 iframe 上。
    // 不替用户关闭（可能丢未保存的编辑），只提示先处理完再切。
    var busy = ['drawer', 'confirmModal', 'shortcutModal'].some(function (id) {
      var el = document.getElementById(id);
      return el && !el.hidden;
    });
    if (busy) {
      flash('请先关闭原后台里打开的编辑弹层，再切到 Y3 测试页', true);
      return;
    }
    St.on = true;
    St.origTitle = ($('#pageTitle') && $('#pageTitle').textContent) || '';
    St.origSub = ($('#pageSub') && $('#pageSub').textContent) || '';
    St.prevActive = $('#nav .nav-item.active[data-tab]');

    if (!St.frame.getAttribute('src')) {
      St.frame.setAttribute('src', BASE + 'index.html?isolated=1&embed=1');
    }
    St.btn.classList.add('is-on');
    document.querySelectorAll('#nav .nav-item').forEach(function (b) {
      if (b !== St.btn) b.classList.remove('active');
    });
    var c = $('#content'); if (c) c.hidden = true;
    St.panel.hidden = false;
    setTitle('果实编辑器 · Y3版（测试）', '独立数据集 · 不写入正式配置 · 原「果实管理」保持不变');
    guardButtons(true);
    updateStagingInfo();
  }

  function exit() {
    if (!St.on) return;
    St.on = false;
    St.btn.classList.remove('is-on');
    St.panel.hidden = true;
    var c = $('#content'); if (c) c.hidden = false;
    guardButtons(false);
    setTitle(St.origTitle, St.origSub);
    if (St.prevActive && St.prevActive.isConnected) St.prevActive.classList.add('active');
    restoreTitleLater();
  }

  /* ---------------- 与 iframe 的桥 ---------------- */
  function requestStaging() {
    if (!St.frame || !St.frame.contentWindow) return;
    St.frame.contentWindow.postMessage({ type: 'y3:requestStaging' }, '*');
  }
  function downloadStaging() {
    var raw = null;
    try { raw = localStorage.getItem(STAGING_KEY); } catch (e) {}
    if (!raw) { flash('暂存区为空，先在 Y3 编辑器里点「暂存到主后台」', true); return; }
    var blob = new Blob([raw], { type: 'application/json;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'Y3果实_暂存配置.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
    flash('已下载暂存配置（仅 JSON，未触碰正式配置）');
  }
  function clearStaging() {
    try { localStorage.removeItem(STAGING_KEY); } catch (e) {}
    updateStagingInfo();
    flash('暂存区已清空。正式配置未受影响。');
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || typeof d !== 'object' || !/^y3:/.test(d.type || '')) return;
    if (St.frame && e.source && e.source !== St.frame.contentWindow) return;
    switch (d.type) {
      case 'y3:staging':
        try {
          localStorage.setItem(STAGING_KEY, JSON.stringify(d.payload || { fruits: [] }));
          updateStagingInfo();
          flash('已暂存到独立数据区 · 未写入 data/game-config.json');
        } catch (err) { flash('暂存失败：' + err.message, true); }
        break;
      case 'y3:exit': exit(); break;
      case 'y3:toast': flash(String(d.text || ''), !!d.bad); break;
      case 'y3:ready': updateStagingInfo(); break;
    }
  });

  /* ---------------- 事件绑定（capture 阶段，不阻断原委托） ---------------- */
  function bind() {
    var nav = $('#nav'); if (!nav) return;

    nav.addEventListener('click', function (e) {
      var t = e.target;
      if (t.closest && t.closest('#y3NavBtn')) {
        // 新按钮：完全自己处理，不让它冒泡到 admin.js 的任何委托
        e.preventDefault(); e.stopPropagation();
        enter();
        return;
      }
      var orig = t.closest && t.closest('[data-tab]');
      if (orig && St.on) {
        // 点回原页签：先还原视图，再【放行】给 admin.js:5599 的 switchTab
        exit();
      }
    }, true);

    // Y3 模式下拦截父页的 Ctrl+S（写正式配置），改为触发 Y3 暂存
    document.addEventListener('keydown', function (e) {
      if (!St.on) return;
      var mod = e.ctrlKey || e.metaKey;
      if (mod && (e.key === 's' || e.key === 'S')) {
        e.preventDefault(); e.stopImmediatePropagation();
        requestStaging();
        flash('Y3 测试模式：已改为暂存到独立数据区，未保存正式配置');
      }
    }, true);

    var p = St.panel;
    p.addEventListener('click', function (e) {
      var id = e.target && e.target.id;
      if (id === 'y3BtnBack') exit();
      else if (id === 'y3BtnStage') { requestStaging(); flash('已向 Y3 编辑器请求暂存…'); }
      else if (id === 'y3BtnDownload') downloadStaging();
      else if (id === 'y3BtnClear') clearStaging();
    });

    // 父页任何代码主动 refresh() 时，若仍在 Y3 模式就补回标题
    ['pageTitle', 'pageSub'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el || typeof MutationObserver === 'undefined') return;
      new MutationObserver(function () {
        if (!St.on) return;
        var a = $('#pageTitle'), b = $('#pageSub');
        if (a && a.textContent.indexOf('Y3版') < 0) {
          setTitle('果实编辑器 · Y3版（测试）', '独立数据集 · 不写入正式配置 · 原「果实管理」保持不变');
          if (b) b.textContent = '独立数据集 · 不写入正式配置 · 原「果实管理」保持不变';
        }
      }).observe(el, { childList: true, characterData: true, subtree: true });
    });
  }

  /* ---------------- 启动 ---------------- */
  function boot() {
    injectCss();
    St.btn = buildNav();
    St.panel = buildPanel();
    if (!St.btn || !St.panel) return;
    St.frame = $('#y3Frame');
    bind();
    updateStagingInfo();

    // 只读调试接口：验收、后续切换方案 B 时用
    window.Y3Embed = {
      enter: enter, exit: exit,
      isOn: function () { return St.on; },
      stagingKey: STAGING_KEY,
      formalKeys: FORMAL_KEYS.slice(),
      base: BASE,
      requestStaging: requestStaging,
      getStaging: function () {
        try { return JSON.parse(localStorage.getItem(STAGING_KEY) || 'null'); }
        catch (e) { return null; }
      }
    };

    // ?y3=1 可直接进测试页，方便回归
    if (/[?&]y3=1(?:&|$)/.test(window.location.search)) setTimeout(enter, 60);
  }

  // 以「关键 DOM 是否已存在」为准，比 readyState 可靠：
  // 本脚本位于 body 末尾时 #nav 必然已解析；若有人把 script 挪到 head，则等 DOMContentLoaded。
  if (!window.Y3Embed && document.getElementById('nav')) boot();
  else if (!window.Y3Embed) document.addEventListener('DOMContentLoaded', function () {
    if (!window.Y3Embed) boot();
  });
})();
