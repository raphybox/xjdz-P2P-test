/* =============================================================================
 * 选技弹珠 · 果实编辑器「语句树」共享契约  SkillScript
 * -----------------------------------------------------------------------------
 * 思路来源：Y3 编辑器的 ECA 触发器。它把 Lua 语句封装成可选择的「文字」，
 * 由 事件 → 条件 → 动作 组成一棵可嵌套的语句树（if/then/else、循环、计时器、
 * 运动完成回调），参数本身也是可选择的文字片段（值 / 变量 / 函数 / 引用）。
 * 编辑器存的是 JSON，编译层把它转成 AST，再由 Formatter 生成 Lua 执行。
 *
 * 本文件把这套范式落到现有项目：
 *   - skill.graph  降级为「模块参数 / 资源对象」（老的 244 个 pixelfx、投射物 PNG 都保留）
 *   - skill.script 新增为「执行逻辑」（语句树），边不再是连线，而是缩进 / 父子
 *   - compile(script) 产出 C.timeline（与上一轮 时序层_schema.js 的展开结果兼容）
 *     以及可读的中文伪代码 / Lua 骨架，供三端共用
 *
 * 零依赖：浏览器 <script> 挂 window.SkillScript；Node 用 require()。
 * ========================================================================== */
(function (root, factory) {
  var api = factory();
  root.SkillScript = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var VERSION = '1.0.0';

  /* --------------------------------------------------------------------------
   * 1. 参数赋值种类（对应 Y3 的「预设 / 值 / 变量 / 函数 / 通用」）
   *    literal 值       {kind:'literal', value:80}
   *    var     变量     {kind:'var', name:'$caster'}
   *    func    函数/表达式 {kind:'func', op:'expr.casterPoint', args:{...}}  ← 文字里嵌套文字
   *    ref     模块引用  {kind:'ref', node:'n_nova', key:'effect'}        ← 引用旧 graph 参数对象
   * ------------------------------------------------------------------------ */

  /* --------------------------------------------------------------------------
   * 2. 语句模板库：template 里的 {key} 就是界面上的彩色槽位
   *    required 必填（红=未填，绿=已填）；children 是可折叠的子语句槽
   * ------------------------------------------------------------------------ */
  var SPEC = {
    /* ---- 事件 ---- */
    'event.skillCast': {
      cat: '事件', tpl: '任意技能事件 · {timing}（关联技能 = {skill}）',
      args: { timing: { label: '时机', type: 'enum', options: ['施放完成', '冷却完成', '开始施放'], required: true },
              skill:  { label: '技能', type: 'skill', required: true } },
      provides: ['$caster', '$skill']
    },
    'event.bodyHit': {
      cat: '事件', tpl: '任意弹珠事件 · 弹珠碰撞（关联技能 = {skill}）',
      args: { skill: { label: '技能', type: 'skill', required: true } },
      provides: ['$caster', '$target', '$skill']
    },
    'event.wallHit': {
      cat: '事件', tpl: '任意弹珠事件 · 撞墙（关联技能 = {skill}）',
      args: { skill: { label: '技能', type: 'skill', required: true } },
      provides: ['$caster', '$wall']
    },
    'event.custom': {
      cat: '事件', tpl: '自定义事件 · {name}',
      args: { name: { label: '事件名', type: 'string', required: true } },
      provides: ['$payload']
    },

    /* ---- 条件 ---- */
    'cond.skillIs': {
      cat: '条件', tpl: '技能判断：当前事件关联技能 等于 {skill}',
      args: { skill: { label: '技能', type: 'skill', required: true } }
    },
    'cond.countGt': {
      cat: '条件', tpl: '{group} 的单位数量 > {n}',
      args: { group: { label: '单位组', type: 'var', required: true },
              n:     { label: '数量', type: 'number', required: true, default: 0 } }
    },
    'cond.compare': {
      cat: '条件', tpl: '{a} {op} {b}',
      args: { a: { label: '左值', type: 'any', required: true },
              op: { label: '比较', type: 'enum', options: ['等于', '不等于', '大于', '小于'], required: true },
              b: { label: '右值', type: 'any', required: true } }
    },
    'cond.inRange': {
      cat: '条件', tpl: '{unit} 位于 {point} 半径 {r} 内',
      args: { unit: { label: '单位', type: 'var', required: true },
              point:{ label: '点', type: 'point', required: true },
              r:    { label: '半径', type: 'number', required: true, default: 80 } }
    },

    /* ---- 变量 / 取值 ---- */
    'setVar': {
      cat: '动作', tpl: '设置变量 {name} = {value}',
      args: { name: { label: '变量名', type: 'varname', required: true },
              value:{ label: '值', type: 'any', required: true } },
      declares: 'name'
    },
    'scopeCircle': {
      cat: '动作', tpl: '以 {point} 为圆心，半径 {r} 筛选 {side} → 保存到 {out}',
      args: { point: { label: '圆心', type: 'point', required: true },
              r:     { label: '半径', type: 'number', required: true, default: 80 },
              side:  { label: '阵营', type: 'enum', options: ['敌方单位', '友方单位', '全部单位'], required: true },
              out:   { label: '保存到', type: 'varname', required: true } },
      declares: 'out'
    },

    /* ---- 执行 / 表现 ---- */
    'forEach': {
      cat: '动作', tpl: '对 {group} 中每个单位执行以下动作',
      args: { group: { label: '单位组', type: 'var', required: true } },
      children: { body: { label: '循环体', min: 1 } },
      provides: ['$it']
    },
    'applyStatus': {
      cat: '动作', tpl: '对 {unit} 施加状态「{status}」{duration} 秒',
      args: { unit: { label: '单位', type: 'var', required: true },
              status:{ label: '状态', type: 'status', required: true },
              duration:{ label: '持续', type: 'number', required: true, default: 1.5 } }
    },
    'createFx': {
      cat: '动作', tpl: '创建特效「{fx}」于 {point}，{attach}，缩放 {scale}',
      args: { fx:    { label: '特效', type: 'fx', required: true },
              point: { label: '位置', type: 'point', required: true },
              attach:{ label: '附着', type: 'enum', options: ['留在原地（一次性）', '跟随弹珠', '跟随敌方'], required: true },
              scale: { label: '缩放', type: 'number', default: 1 } }
    },
    'createZone': {
      cat: '动作', tpl: '创建区域「{fx}」于 {point}，半径 {r}，持续 {life} 秒，{effect}',
      args: { fx:    { label: '区域表现', type: 'fx', required: true },
              point: { label: '位置', type: 'point', required: true },
              r:     { label: '半径', type: 'number', default: 26 },
              life:  { label: '存活', type: 'number', required: true, default: 3 },
              effect:{ label: '区域效果', type: 'enum', options: ['减速 30%', '无逻辑仅表现', '每秒伤害'], default: '无逻辑仅表现' } }
    },
    'damage': {
      cat: '动作', tpl: '对 {unit} 造成 {dtype} 类型的 {amount} 伤害，跳字 {jump}',
      args: { unit:  { label: '单位', type: 'var', required: true },
              dtype: { label: '伤害类型', type: 'enum', options: ['物理', '冰霜', '火焰', '奥术'], default: '物理' },
              amount:{ label: '数值', type: 'number', required: true, default: 0 },
              jump:  { label: '跳字', type: 'bool', default: true } }
    },

    /* ---- 控制流（Y3 范式的核心） ---- */
    'if': {
      cat: '控制流', tpl: 'If - 条件：{cond}',
      args: { cond: { label: '条件', type: 'any', required: true } },
      children: { then: { label: 'Then - 动作', min: 1 }, else: { label: 'Else - 动作', min: 0 } }
    },
    'switch': {
      cat: '控制流', tpl: 'Switch（按 {value} 分支）',
      args: { value: { label: '判断值', type: 'any', required: true } },
      children: { cases: { label: 'Case - 动作', min: 1 }, default: { label: '默认 - 动作', min: 0 } }
    },
    'loop': {
      cat: '控制流', tpl: '指定次数重复执行 {n} 次',
      args: { n: { label: '次数', type: 'number', required: true, default: 1 } },
      children: { body: { label: '循环体', min: 1 } },
      needsCap: 'n'
    },
    'wait': {
      cat: '控制流', tpl: '等待 {sec} 秒，逐条执行其内所有动作',
      args: { sec: { label: '秒数', type: 'number', required: true, default: 0.1 } },
      children: { body: { label: '之后的动作', min: 1 } }
    },
    'timerEvery': {
      cat: '控制流', tpl: '每 {sec} 秒 · 总运行次数 {maxRuns} · 逐条执行其内所有动作',
      args: { sec: { label: '间隔秒', type: 'number', required: true, default: 0.08 },
              maxRuns: { label: '总次数上限', type: 'number', required: true, default: 40 } },
      children: { body: { label: '循环体', min: 1 } },
      needsCap: 'maxRuns'
    },
    'everyPx': {
      cat: '控制流', tpl: '当 {unit} 每移动 {px} 像素（总次数上限 {maxRuns}，超时 {timeout} 秒）',
      args: { unit: { label: '单位', type: 'var', required: true },
              px:   { label: '步长像素', type: 'number', required: true, default: 24 },
              maxRuns:{ label: '总次数上限', type: 'number', required: true, default: 40 },
              timeout:{ label: '超时秒', type: 'number', required: true, default: 3 } },
      children: { body: { label: '每次执行', min: 1 } },
      needsCap: 'maxRuns'
    },
    'motionLine': {
      cat: '控制流', tpl: '为 {unit} 创建直线运动器，方向 {dir}，最大距离 {maxDist}，初始速度 {v0}，加速度 {a}',
      args: { unit: { label: '单位', type: 'var', required: true },
              dir:  { label: '运动方向', type: 'point', required: true },
              maxDist:{ label: '最大距离', type: 'number', default: 0 },
              v0:   { label: '初始速度', type: 'number', default: 0 },
              a:    { label: '加速度', type: 'number', default: 0 } },
      children: { onComplete: { label: '运动完成或执行另外动作', min: 0 } },
      writesVelocity: true
    },
    'callFunc': {
      cat: '函数库', tpl: '调用函数库「{name}」({args})',
      args: { name: { label: '函数名', type: 'string', required: true },
              args: { label: '参数', type: 'string', default: '' } }
    },
    'emitEvent': {
      cat: '动作', tpl: '广播自定义事件 {name}',
      args: { name: { label: '事件名', type: 'string', required: true } }
    },
    'stopTimer': {
      cat: '动作', tpl: '删除计时器 / 回调 {name}',
      args: { name: { label: '名称', type: 'string', required: true } }
    },

    /* ---- 表达式（参数槽里嵌套的「文字」） ---- */
    'expr.casterPoint': {
      cat: '函数', tpl: '{unit} 所在点',
      args: { unit: { label: '单位', type: 'var', required: true } }
    },
    'expr.dirTo': {
      cat: '函数', tpl: '获取从 {a} 到 {b} 的方向',
      args: { a: { label: '起点', type: 'point', required: true },
              b: { label: '终点', type: 'point', required: true } }
    },
    'expr.eventSkill': {
      cat: '函数', tpl: '当前事件关联技能', args: {}
    },
    'expr.eventUnit': {
      cat: '函数', tpl: '当前事件关联单位', args: {}
    },
    'expr.groupCount': {
      cat: '函数', tpl: '{group} 的单位数量',
      args: { group: { label: '单位组', type: 'var', required: true } }
    }
  };

  var CATS = ['事件', '条件', '动作', '控制流', '函数库', '函数'];

  /* --------------------------------------------------------------------------
   * 3. 数据辅助
   * ------------------------------------------------------------------------ */
  function listSpecs(cat) {
    return Object.keys(SPEC).filter(k => !cat || SPEC[k].cat === cat);
  }
  function argVal(node, key) {
    var a = node && node.args && node.args[key];
    if (!a) return undefined;
    if (a.kind === 'literal') return a.value;
    if (a.kind === 'var') return a.name;
    if (a.kind === 'ref') return '[模块:' + a.node + '.' + a.key + ']';
    if (a.kind === 'func') return text(a);
    return a.value;
  }
  function text(node) {
    var s = SPEC[node.op]; if (!s) return '（未知语句 ' + node.op + '）';
    return s.tpl.replace(/\{(\w+)\}/g, function (_, k) {
      var v = argVal(node, k);
      return (v === undefined || v === '' || v === null) ? '〔' + (s.args[k] ? s.args[k].label : k) + '?〕' : String(v);
    });
  }

  /* --------------------------------------------------------------------------
   * 4. 校验：变量作用域 / 必填槽位 / 回调上限 / 本体速度保护
   * ------------------------------------------------------------------------ */
  function validate(script) {
    var issues = [];
    var globalVars = {};
    (script.vars || []).forEach(v => { globalVars[v.name] = v.type || 'any'; });

    function walkList(list, scope, path, ctx) {
      // 同级语句按书写顺序共享作用域：前一句声明的变量，后一句才能引用
      var cur = Object.assign({}, scope);
      (list || []).forEach(function (node, i) {
        walk(node, cur, path + '[' + i + ']', ctx);
        var s = SPEC[node.op];
        if (!s) return;
        if (s.declares) { var nm = argVal(node, s.declares); if (nm) cur[nm] = true; }
        (s.provides || []).forEach(function (v) { cur[v] = true; });
      });
    }
    function walk(node, scope, path, ctx) {
      if (!node || !node.op) { issues.push(err('NO_OP', path, '存在空语句')); return; }
      var s = SPEC[node.op];
      if (!s) { issues.push(err('UNKNOWN_OP', path, '未知语句 ' + node.op)); return; }

      // 必填槽位
      Object.keys(s.args || {}).forEach(function (k) {
        var def = s.args[k], a = node.args && node.args[k];
        var filled = !!a && (
          (a.kind === 'literal' && a.value !== undefined && a.value !== '') ||
          (a.kind === 'var' && !!a.name) ||
          (a.kind === 'ref' && !!a.node) ||
          (a.kind === 'func' && !!a.op));
        if (def.required && !filled) {
          issues.push(err('MISSING_ARG', path, '「' + s.tpl.replace(/[{}]/g, '') + '」的槽位「' + def.label + '」未填'));
        }
        // 变量引用必须在作用域内
        if (a && a.kind === 'var' && !scope[a.name] && !globalVars[a.name] && !ctx.eventProvided[a.name]) {
          issues.push(err('UNDECLARED_VAR', path, '变量 ' + a.name + ' 未声明就引用（作用域外）'));
        }
        // 表达式节点递归校验
        if (a && a.kind === 'func') walk(a, scope, path + '.' + k, ctx);
        // 模块引用检查 graph 里确实有这个节点
        if (a && a.kind === 'ref') {
          var g = (script.graph && script.graph.nodes) || [];
          if (!g.some(n => n.id === a.node)) issues.push(err('BAD_REF', path, '引用了不存在的模块节点 ' + a.node));
        }
      });

      // 重复调度必须给上限（Y3 的「每 x 秒 · 总运行次数」就是为此）
      // 槽位可以填「值」也可以填「变量」：变量由作用域规则保证已声明，这里不再强行要求字面数字
      if (s.needsCap) {
        var capArg = node.args && node.args[s.needsCap];
        var cap = argVal(node, s.needsCap);
        var isVar = capArg && capArg.kind === 'var';
        if (!isVar && (!(Number(cap) > 0) || Number(cap) > 200)) {
          issues.push(err('NO_CAP', path, '重复 / 回调语句必须有 1~200 的总次数上限，防止无限生成'));
        }
        if (isVar && Number(cap) > 0 && Number(cap) > 200) {
          issues.push(err('NO_CAP', path, '变量默认值超过 200，仍可能拖死帧率'));
        }
      }
      // 本体速度保护：用户明确要「弹珠继续移动」
      if (s.writesVelocity && argVal(node, 'unit') === '$caster' && !script.allowCasterMotion) {
        issues.push(err('BLOCKS_CASTER', path,
          '「直线运动器」挂在 $caster 上会接管弹珠本体速度；要「本体继续移动、只挂效果」请改用「每移动 N 像素」回调',
          'warn'));
      }
      // 声明变量
      var inner = Object.assign({}, scope);
      if (s.declares) {
        var nm = argVal(node, s.declares);
        if (nm) inner[nm] = true;
      }
      (s.provides || []).forEach(v => { inner[v] = true; });

      // 子语句槽
      var kids = s.children || {};
      Object.keys(kids).forEach(function (slot) {
        var arr = (node.children && node.children[slot]) || [];
        if (kids[slot].min && arr.length < kids[slot].min) {
          issues.push(err('EMPTY_BODY', path, '「' + kids[slot].label + '」不能为空'));
        }
        // then 分支里声明的局部变量，不能泄漏到 else
        walkList(arr, slot === 'else' ? scope : inner, path + '.' + slot, ctx);
      });
    }
    function err(code, path, msg, level) {
      return { level: level || 'error', code: code, path: path, msg: msg };
    }

    (script.triggers || []).forEach(function (tr, ti) {
      var provided = {};
      if (tr.event && SPEC[tr.event.op]) (SPEC[tr.event.op].provides || []).forEach(v => { provided[v] = true; });
      var scope = Object.assign({}, globalVars);
      Object.keys(provided).forEach(v => { scope[v] = true; });
      var ctx = { eventProvided: provided };
      if (!tr.event) issues.push(err('NO_EVENT', 'triggers[' + ti + ']', '触发器缺少事件'));
      else walk(tr.event, scope, 'triggers[' + ti + '].event', ctx);
      if (tr.event && SPEC[tr.event.op] && SPEC[tr.event.op].cat !== '事件') {
        issues.push(err('BAD_EVENT', 'triggers[' + ti + ']', '事件槽里放的不是事件语句'));
      }
      walkList(tr.conditions, scope, 'triggers[' + ti + '].conditions', ctx);
      walkList(tr.actions, scope, 'triggers[' + ti + '].actions', ctx);
    });
    (script.functions || []).forEach(function (fn, fi) {
      var sc = Object.assign({}, globalVars);
      (fn.params || []).forEach(p => { sc[p.name] = true; });
      walkList(fn.body, sc, 'functions[' + fi + '].body', { eventProvided: {} });
    });
    return issues;
  }

  /* --------------------------------------------------------------------------
   * 5. 编译 → 时间轴（与上一轮 时序层_schema.js 的 expand 结果同构）
   * ------------------------------------------------------------------------ */
  function compile(script, opts) {
    opts = opts || {};
    var speed = Number(opts.speed || 300), T = Number(opts.durationSec || 3);
    var events = [], velocityChanges = [], order = 0;
    var nextOrder = function () { return (order += 10); };

    // 试放参数：变量槽位（如「每 x 秒 · 总次数」填了 $ticks）需要具体值才能展开时间轴。
    // 优先级：存档里的默认值 < 函数参数默认值 < 试放面板传入的 opts.values
    var values = {};
    (script.vars || []).forEach(function (v) { if (v.default !== undefined) values[v.name] = v.default; });
    (script.functions || []).forEach(function (fn) {
      (fn.params || []).forEach(function (p) { if (p.default !== undefined) values[p.name] = p.default; });
    });
    Object.assign(values, opts.values || {});

    function emit(o) { events.push(o); }
    function val(node, key) {
      var a = node && node.args && node.args[key];
      if (a && a.kind === 'var' && values[a.name] !== undefined) return values[a.name];
      return argVal(node, key);
    }

    function expandList(list, at, px, ctx) {
      (list || []).forEach(function (node) { expand(node, at, px, ctx); });
    }
    function expand(node, at, px, ctx) {
      if (!node) return;
      var s = SPEC[node.op];
      if (!s) return;
      var o = nextOrder();
      var label = text(node);

      if (node.op === 'if') {
        // 条件只做门控：then 里的语句仍在同一时刻按顺序展开
        emit({ at: at, on: 'if', nodeId: node.id, label: label, kind: 'gate', order: o, px: px });
        expandList(node.children && node.children.then, at, px, ctx);
        expandList(node.children && node.children.else, at, px, ctx);
        return;
      }
      if (node.op === 'everyPx' || node.op === 'timerEvery') {
        var stepPx = Number(val(node, 'px') || 0);
        var stepSec = node.op === 'everyPx' ? (stepPx / speed) : Number(val(node, 'sec') || 0.08);
        var cap = Math.min(Number(val(node, 'maxRuns') || 1), 200);
        var timeout = node.op === 'everyPx' ? Number(val(node, 'timeout') || T) : (cap * stepSec);
        var body = (node.children && node.children.body) || [];
        for (var i = 0, t = at, p = px; i < cap && (t - at) <= timeout + 1e-6 && t <= T; i++, t += stepSec, p += stepPx) {
          var oo = nextOrder();
          emit({ at: +t.toFixed(4), on: node.op, nodeId: node.id, label: label,
            kind: 'spawn', px: +p.toFixed(1), order: oo, repeat: i + 1, body: body.map(text) });
        }
        return;
      }
      if (node.op === 'wait') {
        var w = Number(val(node, 'sec') || 0);
        emit({ at: +(at + w).toFixed(4), on: 'wait', nodeId: node.id, label: label, kind: 'instant', order: o, px: px });
        expandList(node.children && node.children.body, at + w, px + speed * w, ctx);
        return;
      }
      if (node.op === 'loop') {
        var n = Math.min(Number(val(node, 'n') || 1), 200);
        for (var k = 0; k < n; k++) {
          emit({ at: at, on: 'loop', nodeId: node.id, label: label, kind: 'instant', order: nextOrder(), px: px, repeat: k + 1 });
        }
        return;
      }
      if (node.op === 'motionLine') {
        if (val(node, 'unit') === '$caster') velocityChanges.push(node.id);
        emit({ at: at, on: 'motion', nodeId: node.id, label: label, kind: 'instant', order: o, px: px });
        expandList(node.children && node.children.onComplete, at + 0.001, px, ctx);
        return;
      }
      if (node.op === 'forEach') {
        expandList(node.children && node.children.body, at, px, ctx);
        return;
      }
      if (node.op === 'callFunc') {
        emit({ at: at, on: 'callFunc', nodeId: node.id, label: label, kind: 'instant', order: o, px: px });
        // 函数库复用：把被调用函数的 body 展开进同一时间轴（Y3 函数库语义），限深防自递归
        var fname = argVal(node, 'name');
        var fn = (script.functions || []).filter(function (f) { return f.name === fname; })[0];
        if (fn && fn.body && (ctx.depth || 0) < 3) {
          expandList(fn.body, at, px, { depth: (ctx.depth || 0) + 1 });
        }
        return;
      }
      if (node.op === 'emitEvent' || node.op === 'stopTimer') {
        emit({ at: at, on: node.op, nodeId: node.id, label: label, kind: 'instant', order: o, px: px });
        return;
      }
      // 其余（事件 / 条件 / 变量 / 范围 / 状态 / 特效 / 区域 / 伤害）都是一次性语句
      emit({ at: +at.toFixed(4), on: s.cat, nodeId: node.id, label: label, kind: 'instant', order: o, px: px });
    }

    (script.triggers || []).forEach(function (tr) {
      expand(tr.event, 0, 0, {});
      expandList(tr.conditions, 0, 0, {});
      expandList(tr.actions, 0, 0, {});
    });

    events.sort(function (a, b) { return a.at - b.at || a.order - b.order || String(a.nodeId).localeCompare(String(b.nodeId)); });
    return {
      version: VERSION, durationSec: T, speed: speed,
      casterVelocityUnchanged: velocityChanges.length === 0,
      velocityChangedBy: velocityChanges,
      events: events
    };
  }

  /* --------------------------------------------------------------------------
   * 6. 渲染：中文伪代码（界面就是按这个缩进画）
   * ------------------------------------------------------------------------ */
  function renderNode(node, depth) {
    var s = SPEC[node.op];
    var line = '  '.repeat(depth) + text(node);
    var out = [line];
    Object.keys(s && s.children || {}).forEach(function (slot) {
      var arr = (node.children && node.children[slot]) || [];
      if (!arr.length) return;
      out.push('  '.repeat(depth + 1) + '▾ ' + s.children[slot].label);
      arr.forEach(function (c) { out = out.concat(renderNode(c, depth + 2)); });
    });
    return out;
  }
  function pseudocode(script) {
    var lines = [];
    (script.triggers || []).forEach(function (tr) {
      lines.push('▾ 事件');
      if (tr.event) lines = lines.concat(renderNode(tr.event, 1));
      lines.push('▾ 条件');
      (tr.conditions || []).forEach(c => { lines = lines.concat(renderNode(c, 1)); });
      lines.push('▾ 动作');
      (tr.actions || []).forEach(a => { lines = lines.concat(renderNode(a, 1)); });
    });
    (script.functions || []).forEach(function (fn) {
      lines.push('▾ 函数库 · ' + fn.name + '（' + (fn.params || []).map(p => p.name).join(', ') + '）');
      (fn.body || []).forEach(a => { lines = lines.concat(renderNode(a, 1)); });
    });
    var n = 0;
    return lines.map(l => String(++n).padStart(2, ' ') + '  ' + l).join('\n');
  }

  /* --------------------------------------------------------------------------
   * 7. 渲染：Lua 骨架（对应 Y3「转化成 Lua 代码」；Formatter 模板式输出）
   * ------------------------------------------------------------------------ */
  var LUA = {
    'event.skillCast': "y3.game:event('技能-施放完成', function(trg) local $caster = trg.caster; local $skill = trg.skill;",
    'event.bodyHit':   "y3.game:event('单位-碰撞', function(trg) local $caster = trg.unit; local $target = trg.other;",
    'event.custom':    "y3.game:event('{name}', function(trg) local $payload = trg;",
    'cond.skillIs':    "if $skill ~= '{skill}' then return end",
    'cond.countGt':    "if #{group} <= {n} then return end",
    'if':              "if ({cond}) then",
    'everyPx':         "y3.unit:on_move({unit}, {px}, {maxRuns}, function(u)",
    'timerEvery':      "y3.timer:loop({sec}, {maxRuns}, function()",
    'wait':            "y3.timer:once({sec}, function()",
    'loop':            "for i = 1, {n} do",
    'motionLine':      "y3.motion:line({unit}, {dir}, {maxDist}, {v0}, {a}, function()",
    'forEach':         "for _, $it in ipairs({group}) do",
    'setVar':          "local {name} = {value}",
    'scopeCircle':     "local {out} = y3.select:in_circle({point}, {r}, '{side}')",
    'applyStatus':     "y3.unit:add_buff({unit}, '{status}', {duration})",
    'createFx':        "y3.fx:play('{fx}', {point}, '{attach}', {scale})",
    'createZone':      "y3.zone:create('{fx}', {point}, {r}, {life}, '{effect}')",
    'damage':          "y3.damage:apply({unit}, '{dtype}', {amount}, {jump})",
    'callFunc':        "Func.{name}({args})",
    'emitEvent':       "y3.game:emit('{name}')",
    'stopTimer':       "y3.timer:kill('{name}')"
  };
  function luaLine(node) {
    var t = LUA[node.op];
    if (!t) return '-- ' + text(node);
    return t.replace(/\{(\w+)\}/g, function (_, k) {
      var v = argVal(node, k);
      return (v === undefined || v === '') ? 'nil' : String(v);
    });
  }
  function toLua(script) {
    var out = ['-- 由语句树编译生成（结构与 Y3 ECA Formatter 输出同构）', 'local Func = require("Func")', ''];
    (script.functions || []).forEach(function (fn) {
      out.push('function Func.' + fn.name + '(' + (fn.params || []).map(p => p.name.replace('$', 'v_')).join(', ') + ')');
      (fn.body || []).forEach(n => out.push('  ' + luaLine(n)));
      out.push('end', '');
    });
    function rr(n, d) {
      out.push(string.rep('  ', d) + luaLine(n));
      var s = SPEC[n.op] || {};
      var slots = Object.keys(s.children || {});
      slots.forEach(function (slot, si) {
        var arr = (n.children && n.children[slot]) || [];
        if (!arr.length) return;
        if (slot === 'else' && si > 0) out.push(string.rep('  ', d) + 'else');
        arr.forEach(function (c) { rr(c, d + 1); });
      });
      if (slots.length) out.push(string.rep('  ', d) + 'end');
    }
    (script.triggers || []).forEach(function (tr, i) {
      out.push('-- Trigger ' + (i + 1) + ': ' + (tr.name || '未命名'));
      // 事件行自带 function 开括号：条件与动作都落在同一个回调里
      out.push(luaLine(tr.event));
      (tr.conditions || []).forEach(c => out.push('  ' + luaLine(c)));
      (tr.actions || []).forEach(a => rr(a, 1));
      out.push('end)', '');
    });
    return out.join('\n');
  }
  var string = { rep: function (s, n) { return new Array(Math.max(0, n) + 1).join(s); } };

  /* --------------------------------------------------------------------------
   * 8. 迁移：旧 graph（归属图）→ 等价语句树（行为 100% 不变）
   * ------------------------------------------------------------------------ */
  function fromGraph(sk) {
    var nodes = (sk && sk.graph && sk.graph.nodes) || [];
    return {
      version: VERSION,
      name: (sk && sk.name) || '迁移技能',
      __migrated: true,
      graph: sk.graph,
      triggers: [{
        id: 'tr_legacy', name: '（由旧归属图迁移）',
        event: { id: 'ev_legacy', op: 'event.skillCast',
          args: { timing: { kind: 'literal', value: '施放完成' }, skill: { kind: 'literal', value: sk && sk.name } } },
        conditions: [],
        actions: nodes.map(function (n) {
          return { id: 'ac_' + n.id, op: 'callFunc',
            args: { name: { kind: 'literal', value: '执行模块' },
                    args: { kind: 'literal', value: n.type + ':' + n.id } } };
        })
      }]
    };
  }

  /* ==========================================================================
   * 9. 编辑器通用 API —— 「不针对某个果实」的关键
   *    新增一种能力 = 往 SPEC 注册一条模板，UI / 校验 / 编译 / Lua 全部自动长出
   * ======================================================================== */
  var _uid = 0;
  function uid(prefix) { _uid += 1; return (prefix || 'n') + '_' + Date.now().toString(36) + '_' + _uid.toString(36); }

  /** 运行时注册新语句模板（自定义果实能力的核心扩展点） */
  function registerSpec(op, def) {
    if (!op || !def || !def.cat || !def.tpl) throw new Error('registerSpec 需要 {cat, tpl, args}');
    SPEC[op] = Object.assign({ args: {} }, def);
    if (def.lua) LUA[op] = def.lua;
    return op;
  }
  function unregisterSpec(op) { if (SPEC[op]) { delete SPEC[op]; delete LUA[op]; return true; } return false; }

  /** 深拷贝 + 重映射整棵子树的所有 id（复制粘贴不会撞 id） */
  function cloneNode(node, reassign) {
    var c = JSON.parse(JSON.stringify(node || {}));
    if (reassign !== false) {
      (function walk(n) {
        if (!n || typeof n !== 'object') return;
        if (n.id) n.id = uid('n');
        Object.keys(n).forEach(function (k) {
          var v = n[k];
          if (Array.isArray(v)) v.forEach(walk);
          else if (v && typeof v === 'object' && v.op) walk(v);
          else if (v && typeof v === 'object' && v.kind === 'func') walk(v);
        });
      })(c);
    }
    return c;
  }

  /** 遍历整颗果实里所有语句，cb(node, list, index, parentNode, slotName) */
  function eachNode(fruit, cb) {
    function walkList(list, parentNode, slotName) {
      if (!Array.isArray(list)) return;
      for (var i = 0; i < list.length; i++) {
        var n = list[i];
        if (cb(n, list, i, parentNode, slotName) === false) return false;
        var s = SPEC[n.op] || {};
        var slots = Object.keys(s.children || {});
        for (var j = 0; j < slots.length; j++) {
          var sl = slots[j];
          if (walkList(n.children && n.children[sl], n, sl) === false) return false;
        }
      }
      return true;
    }
    if (!fruit) return;
    (fruit.triggers || []).forEach(function (tr) {
      if (tr.event) cb(tr.event, null, -1, tr, 'event');
      walkList(tr.conditions, tr, 'conditions');
      walkList(tr.actions, tr, 'actions');
    });
    (fruit.functions || []).forEach(function (fn) { walkList(fn.body, fn, 'body'); });
  }

  /** 按 id 找到语句及其所在 list —— 上移/下移/删除/缩进全靠它 */
  function findNode(fruit, id) {
    var hit = null;
    eachNode(fruit, function (n, list, i, parent, slot) {
      if (n.id === id) { hit = { node: n, list: list, index: i, parent: parent, slot: slot }; return false; }
      if (hit) return false;
    });
    return hit;
  }

  /** 收集当前作用域可见的变量名（给槽位编辑器的「变量」下拉用） */
  function visibleVars(fruit, id) {
    var out = {};
    (fruit.vars || []).forEach(function (v) { out[v.name] = '全局'; });
    (fruit.triggers || []).forEach(function (tr) {
      var ev = SPEC[tr.event && tr.event.op];
      if (ev) (ev.provides || []).forEach(function (v) { out[v] = '事件'; });
    });
    (fruit.functions || []).forEach(function (fn) {
      (fn.params || []).forEach(function (p) { out[p.name] = '函数参数'; });
    });
    if (id) {
      // 同一作用域里，选中语句之前声明过的变量才可见
      eachNode(fruit, function (n) {
        if (n.id === id) return false;
        var s = SPEC[n.op];
        if (!s) return;
        if (s.declares) { var nm = argVal(n, s.declares); if (nm) out[nm] = '局部变量'; }
        (s.provides || []).forEach(function (v) { out[v] = '局部变量'; });
      });
    }
    return Object.keys(out).map(function (name) { return { name: name, scope: out[name] }; });
  }

  /** 空白果实模板（新建） */
  function createFruit(name) {
    return {
      version: VERSION,
      id: uid('fruit'),
      name: name || '新果实',
      icon: '', tier: 'rare', charge: 6, enabled: true,
      intro: '', tags: [],
      graph: { nodes: [], edges: [] },
      vars: [],
      functions: [],
      triggers: [{
        id: uid('tr'), name: '主触发器',
        event: { id: uid('ev'), op: 'event.skillCast',
          args: { timing: { kind: 'literal', value: '施放完成' }, skill: { kind: 'literal', value: name || '新果实' } } },
        conditions: [], actions: []
      }],
      meta: { createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
    };
  }

  /** 复制果实（新 id，函数库 / 资源 / 语句全部重映射） */
  function duplicateFruit(fruit, newName) {
    var c = cloneNode(fruit, false);
    c.id = uid('fruit');
    c.name = newName || (fruit.name + ' · 副本');
    var map = {};
    (c.graph.nodes || []).forEach(function (n) { var old = n.id; n.id = uid('res'); map[old] = n.id; });
    eachNode(c, function (n) {
      n.id = uid('n');
      Object.keys(n.args || {}).forEach(function (k) {
        var a = n.args[k];
        if (a && a.kind === 'ref' && map[a.node]) a.node = map[a.node];
      });
    });
    (c.triggers || []).forEach(function (tr) { tr.id = uid('tr'); });
    (c.functions || []).forEach(function (fn) { fn.id = uid('fn'); });
    c.meta = { createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    return c;
  }

  /** 存档兼容：老技能（只有 graph）自动升级成完整果实 */
  function normalize(raw) {
    if (!raw) return createFruit();
    if (raw.script && !raw.triggers) return normalize(raw.script);
    if (!raw.triggers) {
      var migrated = fromGraph(raw);
      var f = createFruit(raw.name || '迁移果实');
      f.triggers = migrated.triggers;
      f.graph = raw.graph || { nodes: [], edges: [] };
      f.intro = raw.intro || '';
      f.tier = raw.tier || 'rare';
      f.charge = raw.charge || 6;
      f.enabled = raw.enabled !== false;
      f.__migrated = true;
      return f;
    }
    raw.version = raw.version || VERSION;
    raw.id = raw.id || uid('fruit');
    raw.meta = raw.meta || { createdAt: new Date().toISOString() };
    raw.graph = raw.graph || { nodes: [], edges: [] };
    raw.vars = raw.vars || [];
    raw.functions = raw.functions || [];
    raw.tags = raw.tags || [];
    eachNode(raw, function (n) { if (!n.id) n.id = uid('n'); });
    return raw;
  }

  /** 导出给 server.js 落盘：剥掉编辑器临时态，写版本号 */
  function serialize(fruit) {
    var c = JSON.parse(JSON.stringify(fruit));
    delete c.__migrated;
    c.meta = Object.assign({}, c.meta, { updatedAt: new Date().toISOString(), schemaVersion: VERSION });
    return c;
  }

  /** 语句库统计（给 UI 显示「30 条可自定义语句」） */
  function specStats() {
    var o = {};
    CATS.forEach(function (c) { o[c] = listSpecs(c).length; });
    return o;
  }

  var Editor = {
    uid: uid, registerSpec: registerSpec, unregisterSpec: unregisterSpec,
    cloneNode: cloneNode, eachNode: eachNode, findNode: findNode, visibleVars: visibleVars,
    createFruit: createFruit, duplicateFruit: duplicateFruit, normalize: normalize,
    serialize: serialize, specStats: specStats
  };

  return {
    VERSION: VERSION, SPEC: SPEC, CATS: CATS, LUA: LUA,
    listSpecs: listSpecs, text: text, argVal: argVal,
    validate: validate, compile: compile,
    pseudocode: pseudocode, toLua: toLua, fromGraph: fromGraph,
    registerSpec: registerSpec, unregisterSpec: unregisterSpec,
    createFruit: createFruit, duplicateFruit: duplicateFruit,
    normalize: normalize, serialize: serialize, specStats: specStats,
    eachNode: eachNode, findNode: findNode, visibleVars: visibleVars, cloneNode: cloneNode,
    Editor: Editor
  };
});
