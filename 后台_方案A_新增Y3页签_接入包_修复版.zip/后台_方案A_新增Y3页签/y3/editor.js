/* 果实逻辑编辑器 · 通用可视化脚本后台
   依赖：语句树_schema.js（window.SkillScript）、果实库.js（window.FRUIT_SEED）
   全部果实共用同一套语句模板；新增能力 = 注册一条 SPEC，不改本文件。 */
(function () {
  'use strict';
  var SS = window.SkillScript, E = SS.Editor;
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };

  function toast(msg, bad) {
    var t = $('#toast'); t.textContent = msg; t.className = 'on' + (bad ? ' err' : '');
    clearTimeout(t._tm); t._tm = setTimeout(function () { t.className = ''; }, 2200);
  }

  /* ---------------- 状态 ---------------- */
  var S = {
    fruits: [], cur: null, selId: null, tab: 'inspect',
    scope: 'trigger', triggerId: null, fnId: null,
    clip: null, undo: [], redo: [], collapsed: {},
    search: '', specCat: '全部', specSearch: '',
    run: { events: [], idx: -1, timer: null, values: {} },
    assign: null, modal: null, insertSlot: null
  };
  /* 方案 A：嵌进现有后台时用独立 localStorage key。
     正式配置是 wowpinball.config.v1 / .snapshots.v1 / .preview.v1，这里绝不触碰。 */
  var QS = new URLSearchParams(window.location.search);
  var EMBED = QS.get('embed') === '1';
  var ISOLATED = QS.get('isolated') === '1' || EMBED;
  var LS = ISOLATED ? 'wowpinball.y3.test.v1' : 'fruit_logic_editor_v1';

  function load() {
    var raw = null;
    try { raw = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) { raw = null; }
    var seed = (window.FRUIT_SEED && window.FRUIT_SEED.fruits) || [];
    S.fruits = (raw && raw.fruits && raw.fruits.length) ? raw.fruits : clone(seed);
    S.fruits = S.fruits.map(SS.normalize);
    S.cur = S.fruits[0] ? S.fruits[0].id : null;
    syncTrigger();
  }
  function save() {
    try { localStorage.setItem(LS, JSON.stringify({ schemaVersion: SS.VERSION, fruits: S.fruits })); }
    catch (e) { /* file:// 下可能禁用，内存态仍可用 */ }
  }
  function fruit() { return S.fruits.filter(function (f) { return f.id === S.cur; })[0] || null; }
  function syncTrigger() {
    var f = fruit(); if (!f) return;
    if (!f.triggers.length) f.triggers.push({ id: E.uid('tr'), name: '主触发器', conditions: [], actions: [] });
    if (!f.triggers.some(function (t) { return t.id === S.triggerId; })) S.triggerId = f.triggers[0].id;
    if (S.scope === 'function') {
      if (!f.functions.some(function (x) { return x.id === S.fnId; })) S.fnId = f.functions[0] ? f.functions[0].id : null;
    }
  }
  function trigger() { var f = fruit(); return f ? f.triggers.filter(function (t) { return t.id === S.triggerId; })[0] : null; }
  function fn() { var f = fruit(); return f ? f.functions.filter(function (x) { return x.id === S.fnId; })[0] : null; }
  /** 当前编辑的主列表（插入 / 粘贴的落点） */
  function mainList() {
    if (S.scope === 'function') { var x = fn(); return x ? (x.body = x.body || []) : null; }
    var t = trigger(); return t ? (t.actions = t.actions || []) : null;
  }

  function snapshot() {
    S.undo.push(JSON.stringify(S.fruits)); if (S.undo.length > 60) S.undo.shift(); S.redo.length = 0;
  }
  function commit(msg) { save(); renderAll(); if (msg) toast(msg); }
  function undo() {
    if (!S.undo.length) return toast('没有可撤销的操作', true);
    S.redo.push(JSON.stringify(S.fruits));
    S.fruits = JSON.parse(S.undo.pop()).map(SS.normalize);
    if (!S.fruits.some(function (f) { return f.id === S.cur; })) S.cur = S.fruits[0] && S.fruits[0].id;
    syncTrigger(); commit('已撤销');
  }
  function redo() {
    if (!S.redo.length) return toast('没有可重做的操作', true);
    S.undo.push(JSON.stringify(S.fruits));
    S.fruits = JSON.parse(S.redo.pop()).map(SS.normalize);
    syncTrigger(); commit('已重做');
  }

  /** 过滤 disabled 语句，供校验 / 编译使用（不改存档） */
  function activeFruit() {
    var f = clone(fruit()); if (!f) return null;
    function strip(list) {
      if (!Array.isArray(list)) return list;
      return list.filter(function (n) { return !n.disabled; }).map(function (n) {
        var s = SS.SPEC[n.op] || {};
        Object.keys(s.children || {}).forEach(function (slot) {
          if (n.children && n.children[slot]) n.children[slot] = strip(n.children[slot]);
        });
        return n;
      });
    }
    (f.triggers || []).forEach(function (t) { t.conditions = strip(t.conditions); t.actions = strip(t.actions); });
    (f.functions || []).forEach(function (x) { x.body = strip(x.body); });
    return f;
  }
  function issues() { var f = activeFruit(); return f ? SS.validate(f) : []; }
  function compiled() {
    var f = activeFruit(); if (!f) return { events: [] };
    return SS.compile(f, { durationSec: 3, speed: 300, values: S.run.values });
  }

  /* ---------------- 模板 / 槽位渲染 ---------------- */
  function segments(tpl) {
    var out = [], last = 0, re = /\{(\w+)\}/g, m;
    while ((m = re.exec(tpl))) {
      if (m.index > last) out.push({ t: 'text', v: tpl.slice(last, m.index) });
      out.push({ t: 'slot', k: m[1] }); last = m.index + m[0].length;
    }
    if (last < tpl.length) out.push({ t: 'text', v: tpl.slice(last) });
    return out;
  }
  function resName(id) {
    var f = fruit(); if (!f) return null;
    var n = (f.graph.nodes || []).filter(function (x) { return x.id === id; })[0];
    return n ? (n.params && n.params.name || n.type) : null;
  }
  function fmt(v) {
    if (v === true) return 'True'; if (v === false) return 'False';
    if (typeof v === 'number') return String(v);
    return String(v);
  }
  function chipHtml(node, key, def, isSub) {
    var a = node.args && node.args[key];
    var cls = 'missing', val = '〔' + (def ? def.label : key) + '?〕';
    if (a) {
      if (a.kind === 'literal') { cls = 'literal'; val = fmt(a.value); }
      else if (a.kind === 'var') { cls = 'var'; val = a.name; }
      else if (a.kind === 'ref') { cls = 'ref'; val = '[' + (resName(a.node) || a.node) + (a.key ? '.' + a.key : '') + ']'; }
      else if (a.kind === 'func') { cls = 'func'; val = '〈' + SS.text(a) + '〉'; }
    } else if (def && !def.required) { cls = 'optional'; val = '〔' + def.label + ' · 可选〕'; }
    return '<span class="chip ' + cls + '" data-act="chip" data-id="' + esc(node.id || '') +
      '" data-key="' + esc(key) + '" title="点击编辑槽位：' + esc(def ? def.label : key) + '">' + esc(val) + '</span>';
  }
  function stmtHtml(node, def, depth) {
    var segs = segments(def.tpl), h = '';
    segs.forEach(function (s) {
      if (s.t === 'text') h += '<span class="txt">' + esc(s.v) + '</span>';
      else h += chipHtml(node, s.k, def.args[s.k]);
    });
    return h;
  }
  var TAG_COLOR = { '事件': 'var(--orange)', '条件': 'var(--green)', '动作': 'var(--blue)',
    '控制流': 'var(--purple)', '函数库': 'var(--gold)', '函数': 'var(--cyan)' };

  function rowHtml(node, depth, counter, ctx) {
    var def = SS.SPEC[node.op] || { tpl: '（未知语句 ' + node.op + '）', args: {}, cat: '?' };
    var slots = Object.keys(def.children || {});
    var hasKids = slots.some(function (s) { return node.children && node.children[s] && node.children[s].length; });
    var folded = !!S.collapsed[node.id];
    var bad = (ctx.badIds || {})[node.id];
    var isPlaying = S.run.idx >= 0 && S.run.events[S.run.idx] && S.run.events[S.run.idx].nodeId === node.id;
    var h = '<div class="row' + (S.selId === node.id ? ' sel' : '') + (bad ? ' bad' : '') +
      (node.disabled ? ' disabled' : '') + (isPlaying ? ' playing' : '') + '" data-id="' + esc(node.id) +
      '" style="padding-left:' + (depth * 24) + 'px">';
    h += '<span class="ln">' + (++counter.n) + '</span>';
    h += '<span class="fold" data-act="fold" data-id="' + esc(node.id) + '">' +
      (slots.length ? (folded ? '▶' : '▾') : '·') + '</span>';
    h += '<span class="tag" style="color:' + (TAG_COLOR[def.cat] || 'var(--dim)') + '">' + esc(def.cat) + '</span>';
    h += '<span class="stmt">' + stmtHtml(node, def, depth) + (bad ? '<span class="errdot">● ' + bad + '</span>' : '') + '</span>';
    h += '<span class="ra">' +
      '<button data-act="quick-insert" data-id="' + esc(node.id) + '" title="在此语句后插入">+</button>' +
      '<button data-act="pick" data-id="' + esc(node.id) + '">选中</button>' +
      '</span></div>';
    if (slots.length && !folded) {
      slots.forEach(function (slot) {
        var sd = def.children[slot];
        var arr = (node.children && node.children[slot]) || [];
        h += '<div class="group" style="padding-left:' + (depth * 24 + 44) + 'px">' +
          esc(sd.label) + ' <span class="plus" data-act="insert-slot" data-parent="' + esc(node.id) +
          '" data-slot="' + esc(slot) + '">＋</span></div>';
        if (!arr.length) h += '<div class="empty" style="padding:4px 0 6px ' + (depth * 24 + 60) +
          'px;text-align:left">（空 · 点上面的 ＋ 添加语句）</div>';
        arr.forEach(function (c) { h += rowHtml(c, depth + 1, counter, ctx); });
      });
    }
    return h;
  }

  function renderTree() {
    var f = fruit(), box = $('#tree');
    if (!f) { box.innerHTML = '<div class="empty">暂无果实，点左侧「+ 新建」</div>'; return; }
    var iss = issues(), badIds = {};
    iss.forEach(function (i) {
      // 从 path 里抽出节点 id
      var m = String(i.path).match(/(?:triggers|functions)\[\d+\]\.|\[\d+\]/g);
      var found = null;
      E.eachNode(f, function (n) { if (String(i.path).indexOf(n.id) >= 0) found = n.id; });
      if (found) badIds[found] = (badIds[found] || 0) + 1;
    });
    var ctx = { badIds: badIds }, counter = { n: 0 }, h = '';

    if (S.scope === 'trigger') {
      var t = trigger(); if (!t) { box.innerHTML = '<div class="empty">该果实没有触发器</div>'; return; }
      h += '<div class="group">▾ 事件 <span class="pill b">触发源</span></div>';
      if (t.event) h += rowHtml(t.event, 0, counter, ctx);
      else h += '<div class="empty">（无事件）</div>';
      h += '<div class="group gr-cond">▾ 条件 <span class="pill g">全部满足才执行</span>' +
        '<span class="plus" data-act="insert-slot-top" data-slot="conditions">＋</span></div>';
      (t.conditions || []).forEach(function (c) { h += rowHtml(c, 0, counter, ctx); });
      h += '<div class="group gr-act">▾ 动作 <span class="pill">逐条顺序执行</span>' +
        '<span class="plus" data-act="insert-slot-top" data-slot="actions">＋</span></div>';
      (t.actions || []).forEach(function (a) { h += rowHtml(a, 0, counter, ctx); });
      if (!(t.actions || []).length) h += '<div class="empty">（空 · 点工具栏「+ 插入语句」开始编排）</div>';
    } else {
      var x = fn();
      if (!x) { box.innerHTML = '<div class="empty">该果实还没有函数。点工具栏「+ 函数」新建一个，之后可用「调用函数库」复用。</div>'; return; }
      h += '<div class="group gr-fn">▾ 函数库 · ' + esc(x.name) + ' <span class="pill p">可复用逻辑</span>' +
        '<span class="plus" data-act="insert-slot-top" data-slot="body">＋</span></div>';
      (x.body || []).forEach(function (a) { h += rowHtml(a, 0, counter, ctx); });
      if (!(x.body || []).length) h += '<div class="empty">（空函数体 · 插入语句）</div>';
    }
    box.innerHTML = h;
  }

  /* ---------------- 左栏 ---------------- */
  function renderLeft() {
    var kw = S.search.trim().toLowerCase();
    var list = S.fruits.filter(function (f) {
      if (!kw) return true;
      return (f.name + ' ' + (f.intro || '') + ' ' + (f.tags || []).join(' ')).toLowerCase().indexOf(kw) >= 0;
    });
    $('#fruitList').innerHTML = list.map(function (f) {
      var v = SS.validate(f).filter(function (i) { return i.level === 'error'; }).length;
      return '<div class="fruit' + (f.id === S.cur ? ' on' : '') + (f.enabled === false ? ' off' : '') +
        '" data-act="select-fruit" data-id="' + esc(f.id) + '" data-name="' + esc(f.name) + '">' +
        '<div class="ic">' + esc((f.name || '?').slice(0, 1)) + '</div>' +
        '<div style="flex:1;min-width:0"><div class="nm">' + esc(f.name) + '</div>' +
        '<div class="tr">' + esc(f.tier) + ' · 充能 ' + esc(f.charge) + 's · ' +
        (f.triggers || []).length + ' 触发器 / ' + (f.functions || []).length + ' 函数' +
        (v ? ' · <span style="color:var(--red)">' + v + ' 错误</span>' : '') + '</div>' +
        '<div class="tagline">' + esc((f.tags || []).slice(0, 3).join(' · ')) + '</div></div></div>';
    }).join('') || '<div class="empty">没有匹配的果实</div>';
    $('#statFruit').textContent = '果实 ' + S.fruits.length + ' 个';
    var st = SS.specStats(), total = Object.keys(st).reduce(function (a, k) { return a + st[k]; }, 0);
    $('#statSpec').textContent = '语句库 ' + total + ' 条';
    var n = issues().filter(function (i) { return i.level === 'error'; }).length;
    var w = issues().filter(function (i) { return i.level === 'warn'; }).length;
    var el = $('#statIssue');
    el.textContent = n ? '✕ ' + n + ' 错误' + (w ? ' / ' + w + ' 警告' : '') : (w ? '⚠ ' + w + ' 警告' : '✓ 0 问题');
    el.className = 'badge' + (n ? ' err' : (w ? ' warn' : ''));
  }

  function renderMeta() {
    var f = fruit(); if (!f) return;
    $('#mName').value = f.name || ''; $('#mTier').value = f.tier || 'rare';
    $('#mCharge').value = f.charge == null ? 6 : f.charge; $('#mIcon').value = f.icon || '';
    $('#mEnabled').value = f.enabled === false ? '0' : '1'; $('#mIntro').value = f.intro || '';
    $('#mTags').value = (f.tags || []).join(', ');
    var tp = $('#triggerPick'), fp = $('#functionPick');
    tp.innerHTML = (f.triggers || []).map(function (t) {
      return '<option value="' + esc(t.id) + '"' + (t.id === S.triggerId ? ' selected' : '') + '>' + esc(t.name) + '</option>';
    }).join('');
    fp.innerHTML = (f.functions || []).map(function (x) {
      return '<option value="' + esc(x.id) + '"' + (x.id === S.fnId ? ' selected' : '') + '>' + esc(x.name) + '</option>';
    }).join('') || '<option value="">（无函数）</option>';
    tp.style.display = S.scope === 'trigger' ? '' : 'none';
    fp.style.display = S.scope === 'function' ? '' : 'none';
    $('#viewScope').value = S.scope;
  }

  /* ---------------- 右栏 tabs ---------------- */
  var TABS = [['inspect', '属性'], ['lib', '语句库'], ['vars', '变量'], ['funcs', '函数库'],
              ['res', '资源'], ['check', '校验'], ['play', '试放'], ['export', '导出']];
  function renderTabs() {
    $('#rightTabs').innerHTML = TABS.map(function (t) {
      return '<button data-act="tab" data-tab="' + t[0] + '"' + (S.tab === t[0] ? ' class="on"' : '') + '>' + t[1] + '</button>';
    }).join('');
  }
  function renderRight() {
    renderTabs(); var b = $('#rightBody'), f = fruit();
    if (!f) { b.innerHTML = '<div class="empty">请先新建或选择一个果实</div>'; return; }
    switch (S.tab) {
      case 'inspect': b.innerHTML = inspectHtml(); break;
      case 'lib': b.innerHTML = libHtml(); break;
      case 'vars': b.innerHTML = varsHtml(); break;
      case 'funcs': b.innerHTML = funcsHtml(); break;
      case 'res': b.innerHTML = resHtml(); break;
      case 'check': b.innerHTML = checkHtml(); break;
      case 'play': b.innerHTML = playHtml(); break;
      case 'export': b.innerHTML = exportHtml(); break;
    }
  }
  function inspectHtml() {
    var f = fruit(); if (!S.selId) return '<div class="h3">语句属性</div><div class="empty">在中间语句树里点选一条语句<br>这里会显示它的全部参数槽位</div>';
    var hit = E.findNode(f, S.selId);
    if (!hit) return '<div class="empty">未找到该语句</div>';
    var n = hit.node, def = SS.SPEC[n.op] || { tpl: n.op, args: {}, cat: '?' };
    var h = '<div class="h3">语句属性</div><div class="card"><div class="t" style="color:' +
      (TAG_COLOR[def.cat] || 'var(--txt)') + '">' + esc(def.cat) + ' · ' + esc(n.op) + '</div>' +
      '<div class="d">' + esc(def.tpl.replace(/\{(\w+)\}/g, '〔$1〕')) + '</div>' +
      '<div class="d" style="margin-top:6px;color:#5f6a78">ID: ' + esc(n.id) + ' · 顺序由所在行号决定</div></div>';
    h += '<div class="h3">参数槽位 <span style="color:#5f6a78;font-weight:400">（点彩色值编辑）</span></div>';
    Object.keys(def.args || {}).forEach(function (k) {
      var d = def.args[k];
      h += '<div class="card" style="padding:8px 10px"><div class="kv"><span class="k">' + esc(d.label) +
        (d.required ? ' <span style="color:var(--red)">*必填</span>' : ' <span style="color:var(--blue)">可选</span>') +
        '</span><span class="v">' + chipHtml(n, k, d) + '</span></div>' +
        '<div class="d" style="margin-top:5px">赋值种类：值 / 变量 / 函数 / 模块引用' +
        (d.type ? ' · 类型 ' + esc(d.type) : '') + (d.options ? ' · 可选项 ' + esc(d.options.join('/')) : '') + '</div></div>';
    });
    h += '<div style="display:flex;gap:6px;margin-top:10px">' +
      '<button data-act="change-op" class="primary">更换语句模板</button>' +
      '<button data-act="toggle-disable">' + (n.disabled ? '启用' : '禁用') + '此语句</button>' +
      '<button data-act="delete-sel" class="danger">删除</button></div>';
    return h;
  }
  function libHtml() {
    var st = SS.specStats();
    var h = '<div class="h3">语句库 · 数据驱动</div>' +
      '<div class="card"><div class="d">所有果实的逻辑都从这里拼出。<b>新增一种能力只需注册一条模板</b>，界面、校验、编译、Lua 生成会自动长出，不需要改编辑器代码。</div>' +
      '<div style="margin-top:7px">' + Object.keys(st).map(function (k) {
        return '<span class="pill ' + ({ '控制流': 'p', '条件': 'g', '动作': 'b' }[k] || '') + '">' + esc(k) + ' ' + st[k] + '</span>';
      }).join('') + '</div></div>';
    h += '<input id="specSearch" placeholder="搜索语句（中文模板 / op）" value="' + esc(S.specSearch) + '">';
    h += '<div style="display:flex;gap:4px;flex-wrap:wrap;margin:8px 0">' +
      ['全部'].concat(SS.CATS).map(function (c) {
        return '<button data-act="spec-cat" data-cat="' + esc(c) + '"' +
          (S.specCat === c ? ' class="primary"' : '') + ' style="padding:3px 7px;font-size:10px">' + esc(c) + '</button>';
      }).join('') + '</div><div id="specList">';
    var kw = S.specSearch.trim().toLowerCase();
    SS.listSpecs().forEach(function (op) {
      var d = SS.SPEC[op];
      if (S.specCat !== '全部' && d.cat !== S.specCat) return;
      if (kw && (op + d.tpl).toLowerCase().indexOf(kw) < 0) return;
      h += '<div class="specitem" data-act="spec-insert" data-op="' + esc(op) + '">' +
        '<div>' + esc(d.tpl.replace(/\{(\w+)\}/g, '〔$1〕')) + '</div>' +
        '<div class="op">' + esc(op) + ' · ' + esc(d.cat) + ' · ' + Object.keys(d.args || {}).length + ' 个槽位' +
        (d.children ? ' · ' + Object.keys(d.children).length + ' 个子槽' : '') + '</div></div>';
    });
    h += '</div><div class="h3" style="margin-top:16px">＋ 注册自定义语句</div>' +
      '<div class="card"><div class="field"><label>语句 op</label><input id="newOp" placeholder="action.myCustom"></div>' +
      '<div class="field"><label>分类</label><select id="newCat">' + SS.CATS.map(function (c) {
        return '<option' + (c === '动作' ? ' selected' : '') + '>' + esc(c) + '</option>';
      }).join('') + '</select></div>' +
      '<div class="field"><label>中文模板</label><input id="newTpl" placeholder="对 {unit} 执行自定义效果，强度 {power}"></div>' +
      '<div class="d" style="margin:6px 0">模板里的 {xxx} 会自动变成彩色槽位；右栏属性面板即刻可编辑。</div>' +
      '<button data-act="register-spec" class="primary">注册到语句库</button></div>';
    return h;
  }
  function varsHtml() {
    var f = fruit(), h = '<div class="h3">变量表</div>' +
      '<div class="card"><div class="d">事件提供变量 → 语句声明变量 → 后续语句引用。校验器会拦截「未声明就引用」和「作用域外引用」。</div></div>';
    h += '<div class="h3">全局变量（可编辑）</div>';
    (f.vars || []).forEach(function (v, i) {
      h += '<div class="card" style="padding:8px"><div class="field" style="margin:0">' +
        '<input data-act="var-name" data-i="' + i + '" value="' + esc(v.name) + '" style="flex:1">' +
        '<select data-act="var-type" data-i="' + i + '" style="width:92px;flex:none">' +
        ['number', 'string', 'unit', 'group', 'bool'].map(function (t) {
          return '<option' + (v.type === t ? ' selected' : '') + '>' + t + '</option>';
        }).join('') + '</select>' +
        '<input data-act="var-default" data-i="' + i + '" placeholder="默认值" value="' + esc(v.default == null ? '' : v.default) + '" style="width:86px;flex:none">' +
        '<button data-act="var-del" data-i="' + i + '" class="danger">✕</button></div></div>';
    });
    h += '<button data-act="var-add" style="margin-bottom:14px">+ 新增全局变量</button>';
    h += '<div class="h3">事件自动提供的变量</div><div class="card">';
    var seen = {};
    (f.triggers || []).forEach(function (t) {
      var d = SS.SPEC[t.event && t.event.op];
      if (d) (d.provides || []).forEach(function (v) { seen[v + '|' + (t.name || '')] = 1; });
    });
    (f.functions || []).forEach(function (x) {
      (x.params || []).forEach(function (p) { seen[p.name + '|函数 ' + x.name] = 1; });
    });
    Object.keys(seen).forEach(function (k) {
      var p = k.split('|');
      h += '<div class="kv"><span class="k">' + esc(p[1]) + '</span><span class="v" style="color:var(--cyan)">' + esc(p[0]) + '</span></div>';
    });
    h += '</div><div class="h3">局部声明（由语句生成）</div><div class="card">';
    var loc = {};
    E.eachNode(f, function (n) {
      var d = SS.SPEC[n.op]; if (!d) return;
      if (d.declares) { var nm = SS.argVal(n, d.declares); if (nm) loc[nm] = d.tpl.split(' ')[0]; }
      (d.provides || []).forEach(function (v) { loc[v] = n.op; });
    });
    Object.keys(loc).forEach(function (k) {
      h += '<div class="kv"><span class="k">' + esc(loc[k]) + '</span><span class="v" style="color:var(--mint)">' + esc(k) + '</span></div>';
    });
    h += '</div>';
    return h;
  }
  function funcsHtml() {
    var f = fruit(), h = '<div class="h3">函数库 · 逻辑复用</div>' +
      '<div class="card"><div class="d">把常用的一段逻辑封装成函数，触发器里用「调用函数库」一句调用。编译时函数体会展开进同一条时间轴，试放与对局一致。</div></div>';
    (f.functions || []).forEach(function (x) {
      h += '<div class="card"><div class="t">' + esc(x.name) + ' <span class="pill p">' + (x.params || []).length + ' 参数</span></div>' +
        '<div class="d">' + esc(x.desc || '') + '</div>' +
        '<div class="d" style="margin-top:5px;color:#5f6a78">' + (x.body || []).length + ' 条语句 · ' +
        esc((x.params || []).map(function (p) { return p.name; }).join(', ')) + '</div>' +
        '<div style="margin-top:8px;display:flex;gap:5px">' +
        '<button data-act="fn-edit" data-id="' + esc(x.id) + '" class="primary">编辑函数体</button>' +
        '<button data-act="fn-rename" data-id="' + esc(x.id) + '">重命名</button>' +
        '<button data-act="fn-del" data-id="' + esc(x.id) + '" class="danger">删除</button></div></div>';
    });
    h += '<button data-act="fn-add">+ 新建函数</button>';
    return h;
  }
  function resHtml() {
    var f = fruit(), h = '<div class="h3">资源对象（旧 graph 素材库）</div>' +
      '<div class="card"><div class="d">这些是你原有的 pixelfx 特效 / 投射物 PNG / 状态对象。语句槽位用「模块引用」指向它们，<b>老素材一个都不用重做</b>。</div></div>';
    (f.graph.nodes || []).forEach(function (n, i) {
      h += '<div class="card" style="padding:8px"><div class="kv"><span class="k">' + esc(n.type) + '</span>' +
        '<span class="v">' + esc(n.params && n.params.name || n.id) + '</span></div>' +
        '<div class="d" style="margin-top:4px">' + esc(n.params && n.params.effect || '（无资源路径）') + '</div>' +
        '<div class="field" style="margin:6px 0 0"><input data-act="res-name" data-i="' + i + '" value="' +
        esc(n.params && n.params.name || '') + '" placeholder="名称">' +
        '<input data-act="res-effect" data-i="' + i + '" value="' + esc(n.params && n.params.effect || '') + '" placeholder="资源路径">' +
        '<button data-act="res-del" data-i="' + i + '" class="danger">✕</button></div></div>';
    });
    h += '<button data-act="res-add">+ 新增资源对象</button>';
    return h;
  }
  function checkHtml() {
    var iss = issues(), h = '<div class="h3">实时校验</div>';
    if (!iss.length) return h + '<div class="ok">✓ 0 个问题 —— 必填槽位、变量作用域、回调上限、资源引用、本体速度保护全部通过，可以发布。</div>' +
      '<div class="card" style="margin-top:12px"><div class="d">这份结果与运行时共用同一套规则；发布前会再跑一次。点击右侧「导出」可拿到落盘 JSON。</div></div>';
    h += '<div class="card" style="border-color:#6b3438"><div class="t" style="color:var(--red)">' +
      iss.filter(function (i) { return i.level === 'error'; }).length + ' 个错误 · ' +
      iss.filter(function (i) { return i.level === 'warn'; }).length + ' 个警告</div>' +
      '<div class="d">点击任意一条可跳转到对应语句；error 会拦住发布。</div></div>';
    iss.forEach(function (i, k) {
      h += '<div class="issue ' + i.level + '" data-act="issue-jump" data-path="' + esc(i.path) + '">' +
        '<b>[' + esc(i.code) + ']</b> ' + esc(i.msg) + '<div style="color:#5f6a78;margin-top:3px;font-size:10px">' +
        esc(i.path) + '</div></div>';
    });
    return h;
  }
  function playHtml() {
    var f = activeFruit(), h = '<div class="h3">试放参数</div>' +
      '<div class="card"><div class="d">变量槽位（如「总次数 = $ticks」）需要一个具体值才能展开时间轴。这里填的值只影响试放，不写进存档。</div></div>';
    var names = {};
    (f.vars || []).forEach(function (v) { names[v.name] = v.default; });
    (f.functions || []).forEach(function (x) { (x.params || []).forEach(function (p) { if (p.default !== undefined) names[p.name] = p.default; }); });
    Object.keys(names).forEach(function (k) {
      h += '<div class="field"><label>' + esc(k) + '</label><input data-act="play-val" data-name="' + esc(k) +
        '" value="' + esc(S.run.values[k] == null ? (names[k] == null ? '' : names[k]) : S.run.values[k]) + '"></div>';
    });
    if (!Object.keys(names).length) h += '<div class="d" style="color:#5f6a78">当前果实没有需要注入的变量参数。</div>';
    h += '<button data-act="play-compile" class="primary" style="margin:10px 0">编译当前果实</button>';
    var T = compiled();
    h += '<div class="h3">编译结果</div><div class="card">' +
      '<div class="kv"><span class="k">事件总数</span><span class="v">' + T.events.length + '</span></div>' +
      '<div class="kv"><span class="k">本体速度不变</span><span class="v" style="color:' +
      (T.casterVelocityUnchanged ? 'var(--green)' : 'var(--red)') + '">' + T.casterVelocityUnchanged + '</span></div>' +
      '<div class="kv"><span class="k">重复 / 回调事件</span><span class="v">' +
      T.events.filter(function (e) { return e.kind === 'spawn'; }).length + '</span></div>' +
      '<div class="kv"><span class="k">确定性</span><span class="v">同一份 AST 三端一致</span></div></div>';
    h += '<div class="h3">事件序列（前 12 条）</div><pre class="code">' +
      esc(T.events.slice(0, 12).map(function (e, i) {
        return String(i + 1).padStart(2) + '  t=' + Number(e.at).toFixed(2) + '  [' + e.on + ']  ' + e.label;
      }).join('\n') || '（无事件）') + '</pre>';
    return h;
  }
  function exportHtml() {
    var f = fruit(), T = compiled();
    var json = JSON.stringify({ schemaVersion: SS.VERSION, exportedAt: new Date().toISOString(), fruits: [SS.serialize(f)] }, null, 2);
    return '<div class="h3">导出 / 落盘</div>' +
      '<div class="card"><div class="d">导出的 JSON 可直接交给 server.js 写入 game-config.json；Lua 骨架与伪代码用于评审和手写扩展。三份来自同一份 AST。</div></div>' +
      '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">' +
      '<button data-act="dl-json" class="primary">↓ 当前果实 JSON</button>' +
      '<button data-act="dl-all">↓ 全部果实</button>' +
      '<button data-act="dl-lua">↓ Lua 骨架</button>' +
      '<button data-act="dl-pseudo">↓ 中文伪代码</button>' +
      '<button data-act="copy-json">复制 JSON</button></div>' +
      '<div class="h3">当前果实 · 编译摘要</div><pre class="code">' +
      esc('果实：' + f.name + '\n触发器：' + f.triggers.length + '  函数：' + f.functions.length +
        '\n资源对象：' + f.graph.nodes.length + '\n校验问题：' + issues().length +
        '\n时间轴事件：' + T.events.length + '\n本体速度不变：' + T.casterVelocityUnchanged) + '</pre>' +
      '<div class="h3">JSON 预览（前 40 行）</div><pre class="code">' +
      esc(json.split('\n').slice(0, 40).join('\n') + '\n  ...') + '</pre>';
  }

  /* ---------------- 底部时间轴 ---------------- */
  function renderBottom() {
    var T = compiled(), evs = T.events;
    S.run.events = evs;
    if (S.run.idx >= evs.length) S.run.idx = -1;
    var box = $('#timeline'), h = '';
    var L = 20, R = 20, W = box.clientWidth || 900;
    var maxT = Math.max(3, evs.length ? evs[evs.length - 1].at : 3);
    function x(t) { return L + (W - L - R) * (t / maxT); }
    h += '<div class="axis"></div>';
    for (var i = 0; i <= 6; i++) {
      var t = maxT * i / 6;
      h += '<div class="tick" style="left:' + x(t) + 'px"><span>' + t.toFixed(1) + 's</span></div>';
    }
    evs.forEach(function (e, k) {
      var cls = e.kind === 'spawn' ? 'spawn' : 'instant';
      h += '<div class="ev ' + cls + (k === S.run.idx ? ' cur' : '') + '" data-act="ev-jump" data-k="' + k +
        '" style="left:' + x(e.at) + 'px" title="t=' + e.at + '  ' + esc(e.label) + '"></div>';
    });
    if (!evs.length) h += '<div class="empty" style="padding:16px">暂无事件 · 点「编译 / 重置」</div>';
    box.innerHTML = h;
    $('#playCount').textContent = (S.run.idx < 0 ? 0 : S.run.idx + 1) + ' / ' + evs.length;
    var cur = S.run.idx >= 0 ? evs[S.run.idx] : null;
    $('#playInfo').textContent = cur ? ('t=' + Number(cur.at).toFixed(2) + '  ' + cur.label) : '点击「试放」编译当前果实';
  }
  function highlightPlaying() {
    $$('#tree .row').forEach(function (r) { r.classList.remove('playing'); });
    var e = S.run.events[S.run.idx]; if (!e) return;
    var r = document.querySelector('#tree .row[data-id="' + CSS.escape(e.nodeId) + '"]');
    if (r) { r.classList.add('playing'); r.scrollIntoView({ block: 'nearest' }); }
  }
  function step(delta) {
    var n = S.run.events.length; if (!n) { toast('先点「编译 / 重置」', true); return; }
    S.run.idx = Math.max(0, Math.min(n - 1, S.run.idx + delta));
    renderBottom(); highlightPlaying();
  }
  function play() {
    if (S.run.timer) { clearInterval(S.run.timer); S.run.timer = null; $('#btnPlay').textContent = '▶ 播放'; return; }
    if (!S.run.events.length) { toast('先点「编译 / 重置」', true); return; }
    if (S.run.idx >= S.run.events.length - 1) S.run.idx = -1;
    $('#btnPlay').textContent = '❚❚ 暂停';
    S.run.timer = setInterval(function () {
      if (S.run.idx >= S.run.events.length - 1) {
        clearInterval(S.run.timer); S.run.timer = null; $('#btnPlay').textContent = '▶ 播放'; return;
      }
      step(1);
    }, 170);
  }

  /* ---------------- 弹窗 ---------------- */
  function openModal(title, body, foot, tabs) {
    S.modal = { title: title };
    $('#modalTitle').textContent = title;
    $('#modalTabs').innerHTML = tabs || '';
    $('#modalBody').innerHTML = body;
    $('#modalFoot').innerHTML = foot || '<button data-act="modal-close">关闭</button>';
    $('#modalWrap').classList.add('on');
  }
  function closeModal() { $('#modalWrap').classList.remove('on'); S.modal = null; S.assign = null; }

  function openLib(target) {
    S.insertSlot = target || null;
    var h = '<input id="modalSearch" placeholder="搜索语句（中文模板 / op）">' +
      '<div id="modalCats" style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:10px">' +
      ['全部'].concat(SS.CATS).map(function (c) {
        return '<button data-act="modal-cat" data-cat="' + esc(c) + '"' +
          (S.specCat === c ? ' class="primary"' : '') + ' style="padding:3px 8px;font-size:10px">' + esc(c) + '</button>';
      }).join('') + '</div><div id="modalSpecList"></div>';
    openModal('插入语句 · 语句库', h, '<button data-act="modal-close">取消</button>',
      '<span style="font-size:11px;color:var(--dim);align-self:center">点一条语句即可插入 · 数据驱动，' +
      SS.listSpecs().length + ' 条可选</span>');
    renderModalSpecs();
  }
  function renderModalSpecs() {
    var kw = ($('#modalSearch') && $('#modalSearch').value || '').trim().toLowerCase();
    var h = '';
    SS.listSpecs().forEach(function (op) {
      var d = SS.SPEC[op];
      if (S.specCat !== '全部' && d.cat !== S.specCat) return;
      if (kw && (op + d.tpl).toLowerCase().indexOf(kw) < 0) return;
      h += '<div class="specitem" data-act="modal-insert" data-op="' + esc(op) + '">' +
        '<div>' + esc(d.tpl.replace(/\{(\w+)\}/g, '〔$1〕')) + '</div>' +
        '<div class="op">' + esc(op) + ' · ' + esc(d.cat) + ' · ' +
        Object.keys(d.args || {}).length + ' 槽位' + (d.children ? ' · 含子槽' : '') + '</div></div>';
    });
    $('#modalSpecList').innerHTML = h || '<div class="empty">没有匹配的语句</div>';
  }
  function newStmtNode(op) {
    var d = SS.SPEC[op];
    var n = { id: E.uid('n'), op: op, args: {} };
    Object.keys(d.args || {}).forEach(function (k) {
      var a = d.args[k];
      if (a.default !== undefined) n.args[k] = { kind: 'literal', value: a.default };
    });
    Object.keys(d.children || {}).forEach(function (s) { n.children = n.children || {}; n.children[s] = []; });
    return n;
  }
  function insertStmt(op, target) {
    var f = fruit(); if (!f) return;
    snapshot();
    var n = newStmtNode(op), placed = false;
    if (target && target.parent) {
      var ph = E.findNode(f, target.parent);
      if (ph) {
        ph.node.children = ph.node.children || {};
        ph.node.children[target.slot] = ph.node.children[target.slot] || [];
        ph.node.children[target.slot].push(n); placed = true;
      }
    }
    if (!placed && target && target.top) {
      var t = trigger();
      if (S.scope === 'function') { var x = fn(); if (x) (x.body = x.body || []).push(n), placed = true; }
      else if (t) { t[target.top] = t[target.top] || []; t[target.top].push(n); placed = true; }
    }
    if (!placed) {
      var hit = S.selId ? E.findNode(f, S.selId) : null;
      if (hit && hit.list) hit.list.splice(hit.index + 1, 0, n);
      else { var ml = mainList(); if (ml) ml.push(n); }
    }
    S.selId = n.id;
    // 事件模板放到事件槽
    if (SS.SPEC[op].cat === '事件' && S.scope === 'trigger' && !target) {
      var tr = trigger(); if (tr) { tr.event = n; var a = mainList(); if (a) { var i = a.indexOf(n); if (i >= 0) a.splice(i, 1); } }
    }
    commit('已插入：' + SS.SPEC[op].cat + ' · ' + op);
  }

  /* ---- 槽位赋值弹窗 ---- */
  function openAssign(nodeId, key, subKey) {
    var f = fruit(), hit = E.findNode(f, nodeId);
    if (!hit) return;
    var holder = hit.node, argKey = key;
    if (subKey) {
      var a = hit.node.args && hit.node.args[key];
      if (!a || a.kind !== 'func') { toast('该槽位不是函数', true); return; }
      holder = a; argKey = subKey;
    }
    S.assign = { nodeId: nodeId, key: key, subKey: subKey || null, tab: 'literal' };
    renderAssign();
  }
  function assignTarget() {
    var f = fruit(), hit = E.findNode(f, S.assign.nodeId);
    if (!hit) return null;
    if (S.assign.subKey) {
      var a = hit.node.args && hit.node.args[S.assign.key];
      if (!a || a.kind !== 'func') { a = { kind: 'func', op: 'expr.eventUnit', args: {} }; hit.node.args[S.assign.key] = a; }
      return { holder: a, key: S.assign.subKey };
    }
    return { holder: hit.node, key: S.assign.key };
  }
  function assignDef() {
    var f = fruit(), hit = E.findNode(f, S.assign.nodeId);
    if (!hit) return { label: S.assign.key, type: 'any' };
    var op = S.assign.subKey ? (hit.node.args[S.assign.key] && hit.node.args[S.assign.key].op) : hit.node.op;
    var d = SS.SPEC[op] || {};
    return (d.args && d.args[S.assign.key === undefined ? '' : (S.assign.subKey || S.assign.key)]) ||
           { label: S.assign.subKey || S.assign.key, type: 'any' };
  }
  function renderAssign() {
    var f = fruit(), t = assignTarget(); if (!t) return;
    var def = assignDef();
    var cur = t.holder.args && t.holder.args[t.key];
    var kinds = [['literal', '值'], ['var', '变量'], ['func', '函数'], ['ref', '模块引用']];
    var tabs = kinds.map(function (k) {
      return '<button data-act="assign-tab" data-tab="' + k[0] + '"' + (S.assign.tab === k[0] ? ' class="on"' : '') + '>' + k[1] + '</button>';
    }).join('');
    var curTxt = '（未填，必填时显示红字）';
    if (cur) {
      var cv = (cur.value != null) ? fmt(cur.value) : (cur.name || cur.node || cur.op || '');
      curTxt = cur.kind + ' · ' + cv;
    }
    var h = '<div class="card"><div class="t">槽位：' + esc(def.label) + ' <span class="pill"> ' + esc(t.key) + '</span></div>' +
      '<div class="d">当前赋值：' + esc(curTxt) + '</div></div>';
    if (S.assign.tab === 'literal') {
      var v = cur && cur.kind === 'literal' ? cur.value : (def.default !== undefined ? def.default : '');
      if (def.options) {
        h += '<div class="field"><label>取值</label><select id="assignVal">' + def.options.map(function (o) {
          return '<option' + (String(v) === String(o) ? ' selected' : '') + '>' + esc(o) + '</option>';
        }).join('') + '</select></div>';
      } else if (def.type === 'bool') {
        h += '<div class="field"><label>取值</label><select id="assignVal"><option value="true"' +
          (v === true || v === 'true' ? ' selected' : '') + '>True</option><option value="false"' +
          (v === false || v === 'false' ? ' selected' : '') + '>False</option></select></div>';
      } else {
        h += '<div class="field"><label>取值</label><input id="assignVal" value="' + esc(v) + '"' +
          (def.type === 'number' ? ' type="number" step="any"' : '') + '></div>';
      }
      h += '<div class="d">类型：' + esc(def.type || 'any') + (def.options ? ' · 枚举选项' : '') + '</div>';
    } else if (S.assign.tab === 'var') {
      var vs = E.visibleVars(f, S.assign.nodeId);
      h += '<div class="h3">选择作用域内可见的变量</div>';
      vs.forEach(function (v) {
        h += '<div class="choice" data-act="assign-var" data-name="' + esc(v.name) + '">' + esc(v.name) +
          '<span class="k">' + esc(v.scope) + '</span></div>';
      });
      h += '<div class="field" style="margin-top:10px"><label>或手输</label><input id="assignVarFree" placeholder="$myVar"></div>';
    } else if (S.assign.tab === 'func') {
      h += '<div class="h3">函数型参数（文字里嵌套文字）</div>';
      SS.listSpecs('函数').concat(SS.listSpecs('条件')).forEach(function (op) {
        var d = SS.SPEC[op];
        h += '<div class="choice" data-act="assign-func" data-op="' + esc(op) + '">' +
          esc(d.tpl.replace(/\{(\w+)\}/g, '〔$1〕')) + '<span class="k">' + esc(op) + '</span></div>';
      });
      if (cur && cur.kind === 'func') {
        h += '<div class="h3" style="margin-top:12px">编辑当前函数的子参数</div>';
        var cd = SS.SPEC[cur.op] || { args: {} };
        Object.keys(cd.args || {}).forEach(function (k) {
          h += '<div class="card" style="padding:7px"><div class="kv"><span class="k">' + esc(cd.args[k].label) +
            '</span><span class="v">' + chipHtml(cur, k, cd.args[k]) + '</span></div></div>';
        });
      }
    } else {
      h += '<div class="h3">引用旧 graph 资源对象</div>';
      (f.graph.nodes || []).forEach(function (n) {
        h += '<div class="choice" data-act="assign-ref" data-node="' + esc(n.id) + '">' +
          esc(n.params && n.params.name || n.id) + '<span class="k">' + esc(n.type) + ' · ' +
          esc(n.params && n.params.effect || '') + '</span></div>';
      });
      if (!(f.graph.nodes || []).length) h += '<div class="empty">还没有资源，去右侧「资源」tab 新增</div>';
    }
    var foot = '<button data-act="assign-clear">清空槽位</button>' +
      '<button data-act="modal-close">取消</button>' +
      (S.assign.tab === 'literal' ? '<button data-act="assign-ok" class="primary">确定</button>' : '');
    openModal('编辑槽位 · ' + def.label, h, foot, tabs);
  }
  function applyAssign(kind, payload) {
    var t = assignTarget(); if (!t) return;
    snapshot();
    t.holder.args = t.holder.args || {};
    if (kind === 'clear') delete t.holder.args[t.key];
    else t.holder.args[t.key] = payload;
    commit('槽位已更新'); closeModal();
  }

  /* ---------------- 果实 / 语句操作 ---------------- */
  function selectFruit(id) {
    snapshot(); S.cur = id; S.selId = null; S.triggerId = null; S.fnId = null; syncTrigger(); commit();
  }
  function newFruit() {
    snapshot();
    var f = SS.createFruit('新果实 ' + (S.fruits.length + 1));
    S.fruits.push(f); S.cur = f.id; S.selId = null; S.scope = 'trigger'; syncTrigger();
    commit('已新建空白果实 · 在语句库里挑语句开始编排');
  }
  function dupFruit(id) {
    snapshot();
    var src = S.fruits.filter(function (f) { return f.id === id; })[0]; if (!src) return;
    var c = SS.duplicateFruit(src); S.fruits.push(c); S.cur = c.id; syncTrigger();
    commit('已复制为「' + c.name + '」');
  }
  function delFruit(id) {
    if (S.fruits.length <= 1) return toast('至少保留一个果实', true);
    snapshot();
    S.fruits = S.fruits.filter(function (f) { return f.id !== id; });
    if (S.cur === id) S.cur = S.fruits[0].id;
    syncTrigger(); commit('已删除果实');
  }
  function move(delta) {
    var f = fruit(), hit = E.findNode(f, S.selId);
    if (!hit || !hit.list) return toast('该语句不能移动（事件行固定在顶部）', true);
    var j = hit.index + delta;
    if (j < 0 || j >= hit.list.length) return toast('已到边界', true);
    snapshot();
    hit.list.splice(hit.index, 1); hit.list.splice(j, 0, hit.node); commit();
  }
  function indent() {
    var f = fruit(), hit = E.findNode(f, S.selId);
    if (!hit || !hit.list || hit.index <= 0) return toast('上一条语句不存在', true);
    var prev = hit.list[hit.index - 1], pd = SS.SPEC[prev.op] || {};
    var slots = Object.keys(pd.children || {});
    if (!slots.length) return toast('上一条语句「' + prev.op + '」没有可缩进的子槽（分支 / 循环 / 回调才行）', true);
    snapshot();
    hit.list.splice(hit.index, 1);
    prev.children = prev.children || {};
    prev.children[slots[0]] = prev.children[slots[0]] || [];
    prev.children[slots[0]].push(hit.node);
    commit('已缩进到「' + pd.children[slots[0]].label + '」');
  }
  function outdent() {
    var f = fruit(), hit = E.findNode(f, S.selId);
    if (!hit || !hit.list) return toast('无法反缩进', true);
    var slot = hit.slot;
    if (slot === 'conditions' || slot === 'actions' || slot === 'body' && hit.parent && !hit.parent.op) {
      return toast('已经在顶层列表了', true);
    }
    var ph = hit.parent && E.findNode(f, hit.parent.id);
    if (!ph || !ph.list) return toast('找不到父语句', true);
    snapshot();
    hit.list.splice(hit.index, 1);
    ph.list.splice(ph.index + 1, 0, hit.node);
    commit('已反缩进到上一层');
  }
  function delStmt() {
    var f = fruit(), hit = E.findNode(f, S.selId);
    if (!hit) return toast('先选中一条语句', true);
    if (!hit.list) return toast('事件行不能删除，请用「更换语句模板」', true);
    snapshot(); hit.list.splice(hit.index, 1); S.selId = null; commit('已删除语句');
  }
  function copyStmt() {
    var f = fruit(), hit = E.findNode(f, S.selId);
    if (!hit) return toast('先选中一条语句', true);
    S.clip = E.cloneNode(hit.node, true); toast('已复制语句子树（含子槽）');
  }
  function pasteStmt() {
    if (!S.clip) return toast('剪贴板为空', true);
    var f = fruit(); snapshot();
    var n = E.cloneNode(S.clip, true);
    var hit = S.selId ? E.findNode(f, S.selId) : null;
    if (hit && hit.list) hit.list.splice(hit.index + 1, 0, n);
    else { var ml = mainList(); if (!ml) return; ml.push(n); }
    S.selId = n.id; commit('已粘贴（所有 id 已重映射）');
  }
  function toggleDisable() {
    var f = fruit(), hit = E.findNode(f, S.selId); if (!hit) return;
    snapshot(); hit.node.disabled = !hit.node.disabled; commit(hit.node.disabled ? '已临时禁用' : '已启用');
  }
  function changeOp() {
    var f = fruit(), hit = E.findNode(f, S.selId); if (!hit) return;
    openModal('更换语句模板 · 当前 ' + hit.node.op,
      '<input id="modalSearch" placeholder="搜索语句"><div id="modalSpecList"></div>',
      '<button data-act="modal-close">取消</button>', '');
    S.insertSlot = { replaceId: hit.node.id };
    renderModalSpecs();
  }

  /* ---------------- 导入 / 导出 ---------------- */
  function download(name, text, type) {
    var blob = new Blob([text], { type: type || 'application/json;charset=utf-8' });
    var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
  }
  function stagingPayload() {
    return {
      schemaVersion: SS.VERSION,
      exportedAt: new Date().toISOString(),
      source: '果实编辑器 · Y3版（测试）',
      isolatedKey: LS,
      fruits: S.fruits.map(SS.serialize)
    };
  }
  function postToParent(type, extra) {
    if (!EMBED || !window.parent || window.parent === window) return;
    try { window.parent.postMessage(Object.assign({ type: type }, extra || {}), '*'); }
    catch (e) { /* 跨源或沙箱环境忽略，下载导出仍可用 */ }
  }
  function stageToParent(quiet) {
    if (!EMBED) { toast('非嵌入模式：请用「导出配置」下载 JSON', true); return; }
    postToParent('y3:staging', { payload: stagingPayload() });
    if (!quiet) toast('已暂存到主后台独立数据区（未写入正式配置）');
  }
  function exportAll() {
    download('果实配置_全部.json', JSON.stringify(stagingPayload(), null, 2));
    if (EMBED) stageToParent(true);   // 导出时顺带暂存，但仍不写 game-config.json
    toast('已导出全部 ' + S.fruits.length + ' 个果实' + (EMBED ? ' · 并已暂存' : ''));
  }

  /* ---------------- 事件委托 ---------------- */
  document.addEventListener('click', function (ev) {
    var el = ev.target.closest('[data-act]'); if (!el) return;
    var act = el.getAttribute('data-act'), id = el.getAttribute('data-id');
    var f = fruit();
    switch (act) {
      case 'select-fruit': selectFruit(id); break;
      case 'tab': S.tab = el.getAttribute('data-tab'); renderRight(); break;
      case 'fold': S.collapsed[id] = !S.collapsed[id]; renderTree(); break;
      case 'pick': S.selId = id; renderTree(); renderRight(); break;
      case 'quick-insert': S.selId = id; openLib(); break;
      case 'insert-slot': openLib({ parent: el.getAttribute('data-parent'), slot: el.getAttribute('data-slot') }); break;
      case 'insert-slot-top': openLib({ top: el.getAttribute('data-slot') }); break;
      case 'chip':
        if (el.closest('#rightBody')) openAssign(S.selId || el.getAttribute('data-id'), el.getAttribute('data-key'));
        else { S.selId = el.getAttribute('data-id'); openAssign(el.getAttribute('data-id'), el.getAttribute('data-key')); }
        break;
      case 'modal-cat': S.specCat = el.getAttribute('data-cat'); renderModalSpecs(); $$('#modalCats button').forEach(function (b) {
        b.classList.toggle('primary', b.getAttribute('data-cat') === S.specCat); }); break;
      case 'modal-insert': {
        var op = el.getAttribute('data-op');
        if (S.insertSlot && S.insertSlot.replaceId) {
          var hit = E.findNode(f, S.insertSlot.replaceId);
          if (hit) { snapshot(); var n = newStmtNode(op); n.id = hit.node.id;
            Object.assign(hit.node, n); S.selId = n.id; commit('已更换语句模板'); closeModal(); }
        } else insertStmt(op, S.insertSlot);
        closeModal(); break;
      }
      case 'spec-insert': S.selId = S.selId || null; insertStmt(el.getAttribute('data-op'), null); break;
      case 'spec-cat': S.specCat = el.getAttribute('data-cat'); renderRight(); break;
      case 'assign-tab': S.assign.tab = el.getAttribute('data-tab'); renderAssign(); break;
      case 'assign-ok': {
        var v = $('#assignVal') ? $('#assignVal').value : '';
        var d = assignDef();
        if (d.type === 'number') v = Number(v);
        else if (d.type === 'bool') v = (v === 'true' || v === true);
        applyAssign('literal', { kind: 'literal', value: v }); break;
      }
      case 'assign-var': applyAssign('var', { kind: 'var', name: el.getAttribute('data-name') }); break;
      case 'assign-func': applyAssign('func', { kind: 'func', op: el.getAttribute('data-op'), args: {} }); break;
      case 'assign-ref': applyAssign('ref', { kind: 'ref', node: el.getAttribute('data-node'), key: 'effect' }); break;
      case 'assign-clear': applyAssign('clear'); break;
      case 'modal-close': closeModal(); break;
      case 'change-op': changeOp(); break;
      case 'toggle-disable': toggleDisable(); break;
      case 'delete-sel': delStmt(); break;
      case 'issue-jump': toast('定位到：' + el.getAttribute('data-path')); S.tab = 'inspect'; renderRight(); break;
      case 'var-add': snapshot(); f.vars.push({ name: '$newVar', type: 'number', default: 0 }); commit(); break;
      case 'var-del': snapshot(); f.vars.splice(Number(el.getAttribute('data-i')), 1); commit(); break;
      case 'fn-add': {
        snapshot(); var nf = { id: E.uid('fn'), name: '新函数 ' + (f.functions.length + 1),
          desc: '', params: [{ name: '$caster', type: 'unit' }], body: [] };
        f.functions.push(nf); S.fnId = nf.id; S.scope = 'function'; syncTrigger(); commit('已新建函数 · 中间已切到函数体视图'); break;
      }
      case 'fn-edit': S.fnId = el.getAttribute('data-id'); S.scope = 'function'; syncTrigger(); commit(); break;
      case 'fn-rename': {
        var x = f.functions.filter(function (v) { return v.id === el.getAttribute('data-id'); })[0];
        if (x) { var nn = prompt('函数名称', x.name); if (nn) { snapshot(); x.name = nn; commit(); } }
        break;
      }
      case 'fn-del': {
        var fid = el.getAttribute('data-id'); snapshot();
        f.functions = f.functions.filter(function (v) { return v.id !== fid; });
        if (S.fnId === fid) S.fnId = null; syncTrigger(); commit(); break;
      }
      case 'res-add': snapshot(); f.graph.nodes.push({ id: E.uid('res'), type: 'fx', x: 0, y: 0,
        params: { name: '新特效', effect: '', scale: 1 } }); commit(); break;
      case 'res-del': snapshot(); f.graph.nodes.splice(Number(el.getAttribute('data-i')), 1); commit(); break;
      case 'register-spec': {
        var op2 = $('#newOp').value.trim(), cat2 = $('#newCat').value, tpl2 = $('#newTpl').value.trim();
        if (!op2 || !tpl2) return toast('请填写 op 和中文模板', true);
        if (SS.SPEC[op2]) return toast('该 op 已存在', true);
        var args = {}, re = /\{(\w+)\}/g, m;
        while ((m = re.exec(tpl2))) args[m[1]] = { label: m[1], type: 'string', required: true };
        try { SS.registerSpec(op2, { cat: cat2, tpl: tpl2, args: args, lua: '-- ' + tpl2 }); }
        catch (e) { return toast(e.message, true); }
        toast('已注册「' + op2 + '」· 全站立即可用'); renderAll(); break;
      }
      case 'play-val': S.run.values[el.getAttribute('data-name')] = el.value; renderBottom(); break;
      case 'play-compile': S.run.idx = -1; renderBottom(); renderRight(); toast('已编译 · ' + compiled().events.length + ' 个事件'); break;
      case 'ev-jump': S.run.idx = Number(el.getAttribute('data-k')); renderBottom(); highlightPlaying(); break;
      case 'dl-json': download(f.name + '.json', JSON.stringify(SS.serialize(f), null, 2)); break;
      case 'dl-all': exportAll(); break;
      case 'dl-lua': download(f.name + '.lua', SS.toLua(activeFruit()), 'text/plain;charset=utf-8'); break;
      case 'dl-pseudo': download(f.name + '_伪代码.txt', SS.pseudocode(activeFruit()), 'text/plain;charset=utf-8'); break;
      case 'copy-json': {
        var txt = JSON.stringify(SS.serialize(f), null, 2);
        if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { toast('已复制 JSON'); });
        else toast('当前环境不支持剪贴板，请用「↓ 当前果实 JSON」'); break;
      }
    }
  });

  /* 输入类事件 */
  document.addEventListener('input', function (ev) {
    var el = ev.target, id = el.id, act = el.getAttribute && el.getAttribute('data-act');
    if (id === 'fruitSearch') { S.search = el.value; renderLeft(); return; }
    if (id === 'specSearch') { S.specSearch = el.value; var sl = $('#specList');
      if (sl) { renderRight(); var n = $('#specSearch'); if (n) { n.focus(); n.setSelectionRange(n.value.length, n.value.length); } } return; }
    if (id === 'modalSearch') { renderModalSpecs(); return; }
    if (!fruit()) return;
    var f = fruit();
    if (act === 'var-name') { f.vars[Number(el.getAttribute('data-i'))].name = el.value; save(); }
    else if (act === 'var-default') { var v = el.value; f.vars[Number(el.getAttribute('data-i'))].default = (v === '' ? undefined : (isNaN(Number(v)) ? v : Number(v))); save(); }
    else if (act === 'res-name') { f.graph.nodes[Number(el.getAttribute('data-i'))].params.name = el.value; save(); renderTree(); }
    else if (act === 'res-effect') { f.graph.nodes[Number(el.getAttribute('data-i'))].params.effect = el.value; save(); }
  });
  document.addEventListener('change', function (ev) {
    var el = ev.target, id = el.id, act = el.getAttribute && el.getAttribute('data-act');
    var f = fruit(); if (!f) return;
    if (id === 'viewScope') { S.scope = el.value; S.selId = null; syncTrigger(); renderAll(); }
    else if (id === 'triggerPick') { S.triggerId = el.value; S.selId = null; renderTree(); renderMeta(); }
    else if (id === 'functionPick') { S.fnId = el.value; S.selId = null; renderTree(); }
    else if (id === 'mTier' || id === 'mEnabled') {
      snapshot(); if (id === 'mTier') f.tier = el.value; else f.enabled = el.value === '1'; commit();
    } else if (act === 'var-type') { f.vars[Number(el.getAttribute('data-i'))].type = el.value; save(); }
  });
  ['mName', 'mCharge', 'mIcon', 'mIntro', 'mTags'].forEach(function (id) {
    document.addEventListener('change', function (ev) {
      if (ev.target.id !== id) return;
      var f = fruit(); if (!f) return; snapshot();
      if (id === 'mName') f.name = ev.target.value || '未命名';
      if (id === 'mCharge') f.charge = Number(ev.target.value) || 0;
      if (id === 'mIcon') f.icon = ev.target.value;
      if (id === 'mIntro') f.intro = ev.target.value;
      if (id === 'mTags') f.tags = ev.target.value.split(/[,，]/).map(function (s) { return s.trim(); }).filter(Boolean);
      commit();
    });
  });

  /* 工具栏按钮 */
  var B = function (id, fn) { var e = $(id); if (e) e.addEventListener('click', fn); };
  B('#btnNew', newFruit); B('#btnImport', function () { $('#fileInput').click(); });
  B('#btnExport', exportAll); B('#btnInsert', function () { openLib(); });
  B('#btnUp', function () { move(-1); }); B('#btnDown', function () { move(1); });
  B('#btnIndent', indent); B('#btnOutdent', outdent);
  B('#btnCopy', copyStmt); B('#btnPaste', pasteStmt);
  B('#btnDisable', toggleDisable); B('#btnDelete', delStmt);
  B('#btnUndo', undo); B('#btnRedo', redo);
  B('#btnCollapse', function () {
    var any = Object.keys(S.collapsed).some(function (k) { return S.collapsed[k]; });
    S.collapsed = {};
    if (!any) { var f2 = fruit(); E.eachNode(f2, function (n) { if (SS.SPEC[n.op] && SS.SPEC[n.op].children) S.collapsed[n.id] = true; }); }
    renderTree();
  });
  B('#btnAddTrigger', function () {
    var f = fruit(); snapshot();
    var t = { id: E.uid('tr'), name: '新触发器 ' + (f.triggers.length + 1),
      event: { id: E.uid('ev'), op: 'event.custom', args: { name: { kind: 'literal', value: '自定义事件' } } },
      conditions: [], actions: [] };
    f.triggers.push(t); S.triggerId = t.id; S.scope = 'trigger'; commit('已新建触发器');
  });
  B('#btnAddFn', function () { document.querySelector('[data-act="fn-add"]') ?
    document.querySelector('[data-act="fn-add"]').click() : (function () {
      var f = fruit(); snapshot(); var nf = { id: E.uid('fn'), name: '新函数 ' + (f.functions.length + 1),
        desc: '', params: [{ name: '$caster', type: 'unit' }], body: [] };
      f.functions.push(nf); S.fnId = nf.id; S.scope = 'function'; syncTrigger(); commit();
    })(); });
  B('#btnCompile', function () { S.run.idx = -1; renderBottom(); renderRight(); toast('已编译 · ' + compiled().events.length + ' 个事件'); });
  B('#btnPlay', play); B('#btnStep', function () { step(1); });
  B('#btnStepBack', function () { step(-1); });
  B('#modalClose', closeModal);
  $('#modalWrap').addEventListener('click', function (e) { if (e.target === this) closeModal(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeModal();
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
  });
  $('#fileInput').addEventListener('change', function (e) {
    var file = e.target.files[0]; if (!file) return;
    var r = new FileReader();
    r.onload = function () {
      try {
        var d = JSON.parse(r.result);
        var arr = Array.isArray(d) ? d : (d.fruits || (d.triggers ? [d] : []));
        if (!arr.length) throw new Error('文件里没有果实数据');
        snapshot();
        arr.forEach(function (x) { S.fruits.push(SS.normalize(x)); });
        S.cur = S.fruits[S.fruits.length - 1].id; syncTrigger();
        commit('已导入 ' + arr.length + ' 个果实');
      } catch (err) { toast('导入失败：' + err.message, true); }
      e.target.value = '';
    };
    r.readAsText(file);
  });
  $('#fruitList').addEventListener('dblclick', function (e) {
    var el = e.target.closest('[data-act="select-fruit"]'); if (!el) return;
    var f = S.fruits.filter(function (x) { return x.id === el.getAttribute('data-id'); })[0];
    if (!f) return; var nn = prompt('重命名果实', f.name);
    if (nn) { snapshot(); f.name = nn; commit(); }
  });
  $('#fruitList').addEventListener('contextmenu', function (e) {
    var el = e.target.closest('[data-act="select-fruit"]'); if (!el) return;
    e.preventDefault(); dupFruit(el.getAttribute('data-id'));
  });
  window.addEventListener('resize', renderBottom);

  /* ---------------- 启动 ---------------- */
  function renderAll() { renderLeft(); renderMeta(); renderTree(); renderRight(); renderBottom(); }
  load(); S.run.idx = -1; renderAll();

  /* ---------------- 方案 A · 嵌入态 ---------------- */
  function initEmbed() {
    if (!EMBED) return;
    ['y3EmbedBadge', 'y3BackBtn', 'y3StageBtn'].forEach(function (id) {
      var e = document.getElementById(id); if (e) e.hidden = false;
    });
    var back = document.getElementById('y3BackBtn');
    if (back) back.addEventListener('click', function () { postToParent('y3:exit'); });
    var stage = document.getElementById('y3StageBtn');
    if (stage) stage.addEventListener('click', function () { stageToParent(); });
    window.addEventListener('message', function (e) {
      var d = e.data;
      if (d && typeof d === 'object' && d.type === 'y3:requestStaging') stageToParent(true);
    });
    postToParent('y3:ready', { lsKey: LS, fruits: S.fruits.length });
  }

  window.FruitEditor = {
    state: S, renderAll: renderAll, SS: SS,
    fruits: function () { return S.fruits; },
    activeFruit: activeFruit, compiled: compiled, issues: issues,
    registerSpec: SS.registerSpec,
    embed: EMBED, isolated: ISOLATED, lsKey: LS,
    stagingPayload: stagingPayload, stageToParent: stageToParent
  };
  initEmbed();
})();
