/* 内置果实样本库（由 果实库.json 生成，供 file:// 直接打开） */
window.FRUIT_SEED = {
  "schemaVersion": "1.0.0",
  "exportedAt": "2026-11-11",
  "note": "内置样本库：6 个果实分别演示 位移回调 / 延时+定时循环 / 碰撞+循环 / 条件分支 / 变量复用 / 函数库封装，全部由同一套 30 条语句模板拼出，无任何果实专属硬编码。",
  "fruits": [
    {
      "version": "1.0.0",
      "id": "fruit_frost",
      "name": "冰霜果实",
      "icon": "ice",
      "tier": "epic",
      "charge": 6,
      "enabled": true,
      "intro": "施放瞬间冻结半径内敌人；弹珠本体继续移动，沿途留下逐渐消融的冰霜路面。",
      "tags": ["控制", "沿途", "范围"],
      "allowCasterMotion": false,
      "graph": {
        "nodes": [
          { "id": "res_nova", "type": "fx", "x": 0, "y": 0, "params": { "name": "冰霜新星", "effect": "ice/frost-nova", "scale": 1 } },
          { "id": "res_road", "type": "fx", "x": 0, "y": 0, "params": { "name": "冰霜路面", "effect": "ice/frost-road", "scale": 1 } },
          { "id": "res_freeze", "type": "status", "x": 0, "y": 0, "params": { "name": "冰冻", "status": "freeze", "duration": 1.5 } }
        ],
        "edges": []
      },
      "vars": [],
      "functions": [
        {
          "id": "fn_frost_burst",
          "name": "冰霜冻结",
          "desc": "范围筛选 → 逐个冰冻 → 施放点播一次新星，可被其他果实 callFunc 复用",
          "params": [ { "name": "$caster", "type": "unit" }, { "name": "$radius", "type": "number" } ],
          "body": [
            {
              "id": "fb_scope", "op": "scopeCircle",
              "args": {
                "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                "r": { "kind": "var", "name": "$radius" },
                "side": { "kind": "literal", "value": "敌方单位" },
                "out": { "kind": "literal", "value": "$targets" }
              }
            },
            {
              "id": "fb_if", "op": "if",
              "args": { "cond": { "kind": "func", "op": "cond.countGt",
                "args": { "group": { "kind": "var", "name": "$targets" }, "n": { "kind": "literal", "value": 0 } } } },
              "children": {
                "then": [
                  { "id": "fb_each", "op": "forEach", "args": { "group": { "kind": "var", "name": "$targets" } },
                    "children": { "body": [
                      { "id": "fb_freeze", "op": "applyStatus",
                        "args": { "unit": { "kind": "var", "name": "$it" }, "status": { "kind": "literal", "value": "冰冻" }, "duration": { "kind": "literal", "value": 1.5 } } },
                      { "id": "fb_nova", "op": "createFx",
                        "args": { "fx": { "kind": "literal", "value": "冰霜新星" },
                                  "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                                  "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 1 } } }
                    ] } }
                ],
                "else": []
              }
            }
          ]
        }
      ],
      "triggers": [
        {
          "id": "tr_frost", "name": "施放主流程",
          "event": { "id": "ev_frost", "op": "event.skillCast",
            "args": { "timing": { "kind": "literal", "value": "施放完成" }, "skill": { "kind": "literal", "value": "冰霜果实" } } },
          "conditions": [ { "id": "cd_frost", "op": "cond.skillIs", "args": { "skill": { "kind": "literal", "value": "冰霜果实" } } } ],
          "actions": [
            { "id": "ac_f1", "op": "callFunc",
              "args": { "name": { "kind": "literal", "value": "冰霜冻结" }, "args": { "kind": "literal", "value": "$caster, 80" } } },
            { "id": "ac_f2", "op": "everyPx",
              "args": { "unit": { "kind": "var", "name": "$caster" }, "px": { "kind": "literal", "value": 24 },
                        "maxRuns": { "kind": "literal", "value": 40 }, "timeout": { "kind": "literal", "value": 3 } },
              "children": { "body": [
                { "id": "ac_f2a", "op": "createZone",
                  "args": { "fx": { "kind": "ref", "node": "res_road", "key": "effect" },
                            "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                            "r": { "kind": "literal", "value": 26 }, "life": { "kind": "literal", "value": 3 },
                            "effect": { "kind": "literal", "value": "减速 30%" } } }
              ] } },
            { "id": "ac_f3", "op": "wait", "args": { "sec": { "kind": "literal", "value": 3 } },
              "children": { "body": [
                { "id": "ac_f3a", "op": "stopTimer", "args": { "name": { "kind": "literal", "value": "冰霜路面" } } }
              ] } }
          ]
        }
      ],
      "meta": { "createdAt": "2026-11-11T00:00:00.000Z", "updatedAt": "2026-11-11T00:00:00.000Z" }
    },

    {
      "version": "1.0.0",
      "id": "fruit_flame",
      "name": "火焰果实",
      "icon": "fire",
      "tier": "epic",
      "charge": 7,
      "enabled": true,
      "intro": "施放后 0.4 秒落点炸裂，随后每 0.5 秒对范围内敌人灼烧一次，共 6 次。逻辑全部封装在函数库里，触发器只有一句。",
      "tags": ["延时", "持续伤害", "函数库"],
      "allowCasterMotion": false,
      "graph": {
        "nodes": [
          { "id": "res_explode", "type": "fx", "x": 0, "y": 0, "params": { "name": "火焰炸裂", "effect": "fire/explosion", "scale": 1 } },
          { "id": "res_burn", "type": "fx", "x": 0, "y": 0, "params": { "name": "灼烧", "effect": "fire/burn", "scale": 1 } }
        ], "edges": []
      },
      "vars": [],
      "functions": [
        {
          "id": "fn_flame", "name": "烈焰爆发",
          "desc": "延时炸裂 + 定时灼烧，参数：施法者、起手延迟、每秒伤害次数",
          "params": [ { "name": "$caster", "type": "unit" },
                      { "name": "$delay", "type": "number", "default": 0.4 },
                      { "name": "$ticks", "type": "number", "default": 6 } ],
          "body": [
            { "id": "fl_scope", "op": "scopeCircle",
              "args": { "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                        "r": { "kind": "literal", "value": 90 }, "side": { "kind": "literal", "value": "敌方单位" },
                        "out": { "kind": "literal", "value": "$targets" } } },
            { "id": "fl_wait", "op": "wait", "args": { "sec": { "kind": "var", "name": "$delay" } },
              "children": { "body": [
                { "id": "fl_fx", "op": "createFx",
                  "args": { "fx": { "kind": "ref", "node": "res_explode", "key": "effect" },
                            "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                            "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 1 } } },
                { "id": "fl_timer", "op": "timerEvery",
                  "args": { "sec": { "kind": "literal", "value": 0.5 }, "maxRuns": { "kind": "var", "name": "$ticks" } },
                  "children": { "body": [
                    { "id": "fl_each", "op": "forEach", "args": { "group": { "kind": "var", "name": "$targets" } },
                      "children": { "body": [
                        { "id": "fl_dmg", "op": "damage",
                          "args": { "unit": { "kind": "var", "name": "$it" }, "dtype": { "kind": "literal", "value": "火焰" },
                                    "amount": { "kind": "literal", "value": 8 }, "jump": { "kind": "literal", "value": true } } }
                      ] } }
                  ] } }
              ] } }
          ]
        }
      ],
      "triggers": [
        { "id": "tr_flame", "name": "施放主流程",
          "event": { "id": "ev_flame", "op": "event.skillCast",
            "args": { "timing": { "kind": "literal", "value": "施放完成" }, "skill": { "kind": "literal", "value": "火焰果实" } } },
          "conditions": [ { "id": "cd_flame", "op": "cond.skillIs", "args": { "skill": { "kind": "literal", "value": "火焰果实" } } } ],
          "actions": [
            { "id": "ac_flame", "op": "callFunc",
              "args": { "name": { "kind": "literal", "value": "烈焰爆发" }, "args": { "kind": "literal", "value": "$caster, 0.4, 6" } } }
          ] }
      ],
      "meta": { "createdAt": "2026-11-11T00:00:00.000Z", "updatedAt": "2026-11-11T00:00:00.000Z" }
    },

    {
      "version": "1.0.0",
      "id": "fruit_chain",
      "name": "连锁闪电果实",
      "icon": "bolt",
      "tier": "legendary",
      "charge": 8,
      "enabled": true,
      "intro": "弹珠碰撞命中后，连续 3 次跳跃伤害并广播连锁事件，供其他触发器监听。",
      "tags": ["碰撞", "循环", "自定义事件"],
      "allowCasterMotion": false,
      "graph": { "nodes": [
        { "id": "res_bolt", "type": "fx", "x": 0, "y": 0, "params": { "name": "闪电链", "effect": "lightning/chain", "scale": 1 } }
      ], "edges": [] },
      "vars": [],
      "functions": [],
      "triggers": [
        { "id": "tr_chain", "name": "碰撞主流程",
          "event": { "id": "ev_chain", "op": "event.bodyHit", "args": { "skill": { "kind": "literal", "value": "连锁闪电果实" } } },
          "conditions": [ { "id": "cd_chain", "op": "cond.skillIs", "args": { "skill": { "kind": "literal", "value": "连锁闪电果实" } } } ],
          "actions": [
            { "id": "ac_c0", "op": "setVar",
              "args": { "name": { "kind": "literal", "value": "$chainLeft" }, "value": { "kind": "literal", "value": 3 } } },
            { "id": "ac_c1", "op": "loop", "args": { "n": { "kind": "literal", "value": 3 } },
              "children": { "body": [
                { "id": "ac_c1a", "op": "damage",
                  "args": { "unit": { "kind": "var", "name": "$target" }, "dtype": { "kind": "literal", "value": "奥术" },
                            "amount": { "kind": "literal", "value": 12 }, "jump": { "kind": "literal", "value": true } } },
                { "id": "ac_c1b", "op": "emitEvent", "args": { "name": { "kind": "literal", "value": "连锁跳跃" } } }
              ] } },
            { "id": "ac_c2", "op": "createFx",
              "args": { "fx": { "kind": "ref", "node": "res_bolt", "key": "effect" },
                        "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                        "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 1 } } }
          ] },
        { "id": "tr_chain_listener", "name": "监听 · 连锁跳跃",
          "event": { "id": "ev_chain2", "op": "event.custom", "args": { "name": { "kind": "literal", "value": "连锁跳跃" } } },
          "conditions": [],
          "actions": [
            { "id": "ac_l1", "op": "createFx",
              "args": { "fx": { "kind": "ref", "node": "res_bolt", "key": "effect" },
                        "point": { "kind": "func", "op": "expr.eventUnit", "args": {} },
                        "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 0.6 } } }
          ] }
      ],
      "meta": { "createdAt": "2026-11-11T00:00:00.000Z", "updatedAt": "2026-11-11T00:00:00.000Z" }
    },

    {
      "version": "1.0.0",
      "id": "fruit_shield",
      "name": "护盾反伤果实",
      "icon": "shield",
      "tier": "rare",
      "charge": 5,
      "enabled": true,
      "intro": "受击时若护盾仍存在则反弹伤害并广播护盾破裂；否则只播一个提示特效。",
      "tags": ["条件分支", "受击", "反伤"],
      "allowCasterMotion": false,
      "graph": { "nodes": [
        { "id": "res_shield_fx", "type": "fx", "x": 0, "y": 0, "params": { "name": "反伤冲击", "effect": "holy/shield-bash", "scale": 1 } },
        { "id": "res_no_shield", "type": "fx", "x": 0, "y": 0, "params": { "name": "护盾已破", "effect": "ui/fizzle", "scale": 0.5 } }
      ], "edges": [] },
      "vars": [],
      "functions": [],
      "triggers": [
        { "id": "tr_shield", "name": "受击主流程",
          "event": { "id": "ev_shield", "op": "event.bodyHit", "args": { "skill": { "kind": "literal", "value": "护盾反伤果实" } } },
          "conditions": [],
          "actions": [
            { "id": "ac_s0", "op": "setVar",
              "args": { "name": { "kind": "literal", "value": "$shieldOn" }, "value": { "kind": "literal", "value": true } } },
            { "id": "ac_s1", "op": "if",
              "args": { "cond": { "kind": "func", "op": "cond.compare",
                "args": { "a": { "kind": "var", "name": "$shieldOn" }, "op": { "kind": "literal", "value": "等于" },
                          "b": { "kind": "literal", "value": true } } } },
              "children": {
                "then": [
                  { "id": "ac_s1a", "op": "damage",
                    "args": { "unit": { "kind": "var", "name": "$target" }, "dtype": { "kind": "literal", "value": "物理" },
                              "amount": { "kind": "literal", "value": 15 }, "jump": { "kind": "literal", "value": true } } },
                  { "id": "ac_s1b", "op": "createFx",
                    "args": { "fx": { "kind": "ref", "node": "res_shield_fx", "key": "effect" },
                              "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                              "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 1 } } },
                  { "id": "ac_s1c", "op": "emitEvent", "args": { "name": { "kind": "literal", "value": "护盾破裂" } } }
                ],
                "else": [
                  { "id": "ac_s1d", "op": "createFx",
                    "args": { "fx": { "kind": "ref", "node": "res_no_shield", "key": "effect" },
                              "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                              "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 0.5 } } }
                ]
              } }
          ] }
      ],
      "meta": { "createdAt": "2026-11-11T00:00:00.000Z", "updatedAt": "2026-11-11T00:00:00.000Z" }
    },

    {
      "version": "1.0.0",
      "id": "fruit_magnet",
      "name": "磁引果实",
      "icon": "magnet",
      "tier": "rare",
      "charge": 5,
      "enabled": true,
      "intro": "施放后每 0.2 秒在弹珠当前位置生成一次磁力波，共 12 次；2.5 秒后停止计时器。",
      "tags": ["定时循环", "变量", "计时器"],
      "allowCasterMotion": false,
      "graph": { "nodes": [
        { "id": "res_magnet", "type": "fx", "x": 0, "y": 0, "params": { "name": "磁力波", "effect": "arcane/magnet-wave", "scale": 1 } }
      ], "edges": [] },
      "vars": [],
      "functions": [],
      "triggers": [
        { "id": "tr_magnet", "name": "施放主流程",
          "event": { "id": "ev_magnet", "op": "event.skillCast",
            "args": { "timing": { "kind": "literal", "value": "施放完成" }, "skill": { "kind": "literal", "value": "磁引果实" } } },
          "conditions": [],
          "actions": [
            { "id": "ac_m1", "op": "timerEvery",
              "args": { "sec": { "kind": "literal", "value": 0.2 }, "maxRuns": { "kind": "literal", "value": 12 } },
              "children": { "body": [
                { "id": "ac_m1a", "op": "setVar",
                  "args": { "name": { "kind": "literal", "value": "$pullPoint" },
                            "value": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } } } },
                { "id": "ac_m1b", "op": "createFx",
                  "args": { "fx": { "kind": "ref", "node": "res_magnet", "key": "effect" },
                            "point": { "kind": "var", "name": "$pullPoint" },
                            "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 1 } } }
              ] } },
            { "id": "ac_m2", "op": "wait", "args": { "sec": { "kind": "literal", "value": 2.5 } },
              "children": { "body": [
                { "id": "ac_m2a", "op": "stopTimer", "args": { "name": { "kind": "literal", "value": "磁力循环" } } }
              ] } }
          ] }
      ],
      "meta": { "createdAt": "2026-11-11T00:00:00.000Z", "updatedAt": "2026-11-11T00:00:00.000Z" }
    },

    {
      "version": "1.0.0",
      "id": "fruit_split",
      "name": "分裂弹果实",
      "icon": "split",
      "tier": "epic",
      "charge": 6,
      "enabled": true,
      "intro": "命中后循环 3 次生成碎片弹体并各结算一次伤害，演示「循环 + 旧 graph 资源引用」。",
      "tags": ["循环", "投射物", "资源引用"],
      "allowCasterMotion": false,
      "graph": { "nodes": [
        { "id": "res_shard", "type": "fx", "x": 0, "y": 0, "params": { "name": "碎片弹", "effect": "physical/shard", "scale": 0.6 } },
        { "id": "res_core", "type": "projectile", "x": 0, "y": 0, "params": { "name": "母弹", "count": 1, "speed": 300 } }
      ], "edges": [] },
      "vars": [],
      "functions": [],
      "triggers": [
        { "id": "tr_split", "name": "命中主流程",
          "event": { "id": "ev_split", "op": "event.bodyHit", "args": { "skill": { "kind": "literal", "value": "分裂弹果实" } } },
          "conditions": [],
          "actions": [
            { "id": "ac_p1", "op": "loop", "args": { "n": { "kind": "literal", "value": 3 } },
              "children": { "body": [
                { "id": "ac_p1a", "op": "createFx",
                  "args": { "fx": { "kind": "ref", "node": "res_shard", "key": "effect" },
                            "point": { "kind": "func", "op": "expr.casterPoint", "args": { "unit": { "kind": "var", "name": "$caster" } } },
                            "attach": { "kind": "literal", "value": "留在原地（一次性）" }, "scale": { "kind": "literal", "value": 0.6 } } },
                { "id": "ac_p1b", "op": "damage",
                  "args": { "unit": { "kind": "var", "name": "$target" }, "dtype": { "kind": "literal", "value": "物理" },
                            "amount": { "kind": "literal", "value": 6 }, "jump": { "kind": "literal", "value": true } } }
              ] } },
            { "id": "ac_p2", "op": "stopTimer", "args": { "name": { "kind": "literal", "value": "分裂" } } }
          ] }
      ],
      "meta": { "createdAt": "2026-11-11T00:00:00.000Z", "updatedAt": "2026-11-11T00:00:00.000Z" }
    }
  ]
}
;
